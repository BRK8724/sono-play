export type SkinId = "pilot" | "gold" | "santa";
export type BackgroundId = "classic" | "sunset" | "city";
export type PlayerSnapshot = {
  displayName: string;
  best: number;
  games: number;
  pipes: number;
  coins: number;
  owned: SkinId[];
  selected: SkinId;
  ownedBackgrounds: BackgroundId[];
  selectedBackground: BackgroundId;
  sound: boolean;
  lives: number;
};

export type ItemKind = "skin" | "background";
export interface RunResult {
  snapshot: PlayerSnapshot;
  awardedCoins: number;
}
export interface GameGateway {
  bootstrap(): Promise<PlayerSnapshot>;
  startRun(
    requestId: string,
  ): Promise<{ runId: string; snapshot: PlayerSnapshot }>;
  finishRun(runId: string, score: number, taps: number[]): Promise<RunResult>;
  purchase(
    kind: ItemKind,
    itemId: string,
    requestId: string,
  ): Promise<PlayerSnapshot>;
  equip(kind: ItemKind, itemId: string): Promise<PlayerSnapshot>;
  buyLives(packId: string, requestId: string): Promise<PlayerSnapshot>;
}
