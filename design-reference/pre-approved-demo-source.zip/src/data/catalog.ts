import type { SkinId, BackgroundId } from "./contracts";
export const SKINS: {
  id: SkinId;
  name: string;
  cost: number;
  icon: string;
  color: number;
}[] = [
  { id: "pilot", name: "Sono", cost: 0, icon: "🛩️", color: 0xffffff },
  { id: "gold", name: "Gold Sono", cost: 450, icon: "✨", color: 0xffd756 },
  { id: "santa", name: "Santa Sono", cost: 350, icon: "🎅", color: 0xff8c8c },
];
export const BACKGROUNDS: {
  id: BackgroundId;
  name: string;
  cost: number;
  imageClass: string;
}[] = [
  { id: "classic", name: "Classic", cost: 0, imageClass: "classic" },
  { id: "sunset", name: "Sunset", cost: 450, imageClass: "sunset" },
  { id: "city", name: "Blue City", cost: 350, imageClass: "city" },
];

export const LIFE_PACKS = [
  { id: "one", lives: 1, cost: 100 },
  { id: "five", lives: 5, cost: 400 },
  { id: "twelve", lives: 12, cost: 900 },
] as const;
