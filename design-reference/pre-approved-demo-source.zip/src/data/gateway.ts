/// <reference types="vite/client" />
import type {
  GameGateway,
  PlayerSnapshot,
  ItemKind,
  RunResult,
} from "./contracts";
declare global {
  interface Window {
    SonoPlayHost?: { launch(assertion: string): void };
  }
}
let deliverAssertion: ((assertion: string) => void) | undefined;
const assertionReady = new Promise<string>((resolve) => {
  deliverAssertion = resolve;
});
window.SonoPlayHost = {
  launch(assertion: string) {
    if (
      typeof assertion === "string" &&
      assertion.length > 20 &&
      assertion.length < 16384
    )
      deliverAssertion?.(assertion);
  },
};
class HttpGateway implements GameGateway {
  private async request<T>(
    path: string,
    body?: unknown,
    key?: string,
  ): Promise<T> {
    const response = await fetch(`/api${path}`, {
      method: body ? "POST" : "GET",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
        ...(key ? { "Idempotency-Key": key } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(10000),
    });
    if (!response.ok) {
      const detail = await response.json().catch(() => ({}));
      throw new Error(
        detail.code === "NO_LIVES"
          ? "NO_LIVES"
          : response.status === 401
            ? "Session expired. Reopen Sono Play."
            : "Connection failed. Please retry.",
      );
    }
    return response.json() as Promise<T>;
  }
  async bootstrap(): Promise<PlayerSnapshot> {
    const existing = await fetch("/api/bootstrap", {
      credentials: "same-origin",
      signal: AbortSignal.timeout(10000),
    });
    if (existing.ok) return existing.json() as Promise<PlayerSnapshot>;
    if (existing.status !== 401)
      throw new Error("Play service is unavailable. Please retry.");
    window.dispatchEvent(new Event("sono:host-ready"));
    const assertion = await Promise.race([
      assertionReady,
      new Promise<never>((_, reject) =>
        setTimeout(
          () =>
            reject(
              new Error("Open Sono Play from the Flutter app to sign in."),
            ),
          15000,
        ),
      ),
    ]);
    await this.request("/session/exchange", { assertion });
    return this.request<PlayerSnapshot>("/bootstrap");
  }
  startRun(key: string) {
    return this.request<{ runId: string; snapshot: PlayerSnapshot }>(
      "/runs/start",
      {},
      key,
    );
  }
  finishRun(runId: string, score: number, taps: number[]) {
    return this.request<RunResult>(
      `/runs/${encodeURIComponent(runId)}/finish`,
      { score, taps },
      `finish:${runId}`,
    );
  }
  purchase(kind: ItemKind, itemId: string, key: string) {
    return this.request<PlayerSnapshot>("/orders", { kind, itemId }, key);
  }
  equip(kind: ItemKind, itemId: string) {
    return this.request<PlayerSnapshot>("/inventory/equip", { kind, itemId });
  }
  buyLives(packId: string, key: string) {
    return this.request<PlayerSnapshot>("/lives/purchase", { packId }, key);
  }
}
export async function createGateway(): Promise<GameGateway> {
  if (import.meta.env.VITE_DATA_MODE === "api") return new HttpGateway();
  if (
    import.meta.env.VITE_DATA_MODE &&
    import.meta.env.VITE_DATA_MODE !== "mock"
  )
    throw new Error("Invalid VITE_DATA_MODE");
  const { MockGateway } = await import("./mock");
  return new MockGateway();
}
