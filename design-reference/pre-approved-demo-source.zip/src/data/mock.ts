import type {
  GameGateway,
  PlayerSnapshot,
  ItemKind,
  RunResult,
} from "./contracts";
import { SKINS, BACKGROUNDS, LIFE_PACKS } from "./catalog";
import { NEW_PLAYER } from "./fixtures";
const KEY = "sono-play-mock-v4";
type DB = {
  regeneratedAt?: number;
  player: PlayerSnapshot;
  runs: Record<string, { started: number; result?: RunResult }>;
  requests: Record<string, unknown>;
};
const fresh = (): DB => ({
  player: structuredClone(NEW_PLAYER),
  runs: {},
  requests: {},
});
function read(): DB {
  try {
    const value = JSON.parse(localStorage.getItem(KEY) || "null") as DB | null;
    if (
      !value ||
      !Number.isSafeInteger(value.player?.coins) ||
      value.player.coins < 0 ||
      !Number.isSafeInteger(value.player.lives)
    )
      return fresh();
    return value;
  } catch {
    return fresh();
  }
}
export class MockGateway implements GameGateway {
  private async transaction<T>(action: (db: DB) => T): Promise<T> {
    const work = () => {
      const db = read();
      const now = Date.now();
      db.regeneratedAt ??= now;
      if (db.player.lives < 5) {
        const gained = Math.floor((now - db.regeneratedAt) / 600000);
        if (gained > 0) {
          db.player.lives = Math.min(5, db.player.lives + gained);
          db.regeneratedAt += gained * 600000;
        }
      } else db.regeneratedAt = now;
      const result = action(db);
      localStorage.setItem(KEY, JSON.stringify(db));
      return structuredClone(result);
    };
    return navigator.locks ? navigator.locks.request(KEY, work) : work();
  }
  bootstrap() {
    return this.transaction((db) => db.player);
  }
  startRun(requestId: string) {
    return this.transaction((db) => {
      if (db.requests[requestId])
        return db.requests[requestId] as {
          runId: string;
          snapshot: PlayerSnapshot;
        };
      if (db.player.lives < 1) throw new Error("NO_LIVES");
      db.player.lives--;
      db.player.games++;
      const runId = crypto.randomUUID();
      db.runs[runId] = { started: Date.now() };
      const result = { runId, snapshot: structuredClone(db.player) };
      db.requests[requestId] = result;
      return result;
    });
  }
  finishRun(runId: string, score: number, _taps: number[]) {
    return this.transaction((db) => {
      const run = db.runs[runId];
      if (!run) throw new Error("Run expired. Please start again.");
      if (run.result) return run.result;
      // Mock only. Production must verify run evidence and calculate reward on Play server.
      if (!Number.isSafeInteger(score) || score < 0 || score > 10000)
        throw new Error("Invalid result");
      const awardedCoins = Math.min(score * 10, 60);
      db.player.coins += awardedCoins;
      db.player.pipes += score;
      db.player.best = Math.max(score, db.player.best);
      run.result = { snapshot: structuredClone(db.player), awardedCoins };
      return run.result;
    });
  }
  purchase(kind: ItemKind, itemId: string, requestId: string) {
    return this.transaction((db) => {
      if (db.requests[requestId])
        return db.requests[requestId] as PlayerSnapshot;
      const catalog = kind === "skin" ? SKINS : BACKGROUNDS;
      const item = catalog.find((i) => i.id === itemId);
      if (!item) throw new Error("Item unavailable");
      const owned = (
        kind === "skin" ? db.player.owned : db.player.ownedBackgrounds
      ) as string[];
      if (!owned.includes(itemId)) {
        if (db.player.coins < item.cost)
          throw new Error("Not enough bonus coins");
        db.player.coins -= item.cost;
        owned.push(itemId);
      }
      if (kind === "skin")
        db.player.selected = itemId as PlayerSnapshot["selected"];
      else
        db.player.selectedBackground =
          itemId as PlayerSnapshot["selectedBackground"];
      db.requests[requestId] = structuredClone(db.player);
      return db.player;
    });
  }
  equip(kind: ItemKind, itemId: string) {
    return this.transaction((db) => {
      const owned = (
        kind === "skin" ? db.player.owned : db.player.ownedBackgrounds
      ) as string[];
      if (!owned.includes(itemId)) throw new Error("Item is not owned");
      if (kind === "skin")
        db.player.selected = itemId as PlayerSnapshot["selected"];
      else
        db.player.selectedBackground =
          itemId as PlayerSnapshot["selectedBackground"];
      return db.player;
    });
  }
  buyLives(packId: string, requestId: string) {
    return this.transaction((db) => {
      if (db.requests[requestId])
        return db.requests[requestId] as PlayerSnapshot;
      const pack = LIFE_PACKS.find((p) => p.id === packId);
      if (!pack) throw new Error("Invalid life pack");
      if (db.player.coins < pack.cost)
        throw new Error("Not enough bonus coins");
      if (db.player.lives + pack.lives > 99)
        throw new Error("Your lives are full");
      db.player.coins -= pack.cost;
      db.player.lives += pack.lives;
      db.requests[requestId] = structuredClone(db.player);
      return db.player;
    });
  }
}
