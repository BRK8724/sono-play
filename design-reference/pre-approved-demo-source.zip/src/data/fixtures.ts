import type { PlayerSnapshot } from "./contracts";
export const NEW_PLAYER: PlayerSnapshot = {
  displayName: "Demo Pilot",
  best: 0,
  games: 0,
  pipes: 0,
  coins: 1000,
  owned: ["pilot"],
  selected: "pilot",
  ownedBackgrounds: ["classic"],
  selectedBackground: "classic",
  sound: true,
  lives: 5,
};

export const DEMO_LEADERS = Array.from({ length: 10 }, (_, i) => ({
  name: `Pilot ${i + 1}`,
  score: 210 - i * 13,
}));
