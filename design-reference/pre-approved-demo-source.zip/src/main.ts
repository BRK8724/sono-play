/// <reference types="vite/client" />
import Phaser from "phaser";
import { GameAudio } from "./audio/GameAudio";
import "./style.css";
import { createGateway } from "./data/gateway";
import { SKINS, BACKGROUNDS, LIFE_PACKS } from "./data/catalog";

async function boot(): Promise<void> {
  const gateway = await createGateway();
  let save = await gateway.bootstrap();
  const pending = sessionStorage.getItem("sono-pending-run");
  if (pending) {
    const run = JSON.parse(pending);
    const result = await gateway.finishRun(run.id, run.score, run.taps);
    save = result.snapshot;
    sessionStorage.removeItem("sono-pending-run");
  }
  document.getElementById("profile-name")!.textContent =
    save.displayName || "Player";
  if (import.meta.env.VITE_DATA_MODE === "api")
    document
      .querySelectorAll(".demo-label")
      .forEach((el) => (el.textContent = ""));
  let busy = false;
  const preferences = {
    sound: localStorage.getItem("sono-sound") !== "off",
    haptics: localStorage.getItem("sono-haptics") !== "off",
  };
  let selectedPack: string = "one";
  const lifeKeys = new Map<string, string>();
  function report(error: unknown): void {
    el("error-dialog").classList.remove("hidden");
    setText(
      "error-message",
      error instanceof Error
        ? error.message
        : "Something went wrong. Please retry.",
    );
  }
  async function command(action: () => Promise<void>): Promise<void> {
    if (busy) return;
    busy = true;
    document.body.classList.add("busy");
    try {
      await action();
    } catch (error) {
      report(error);
    } finally {
      busy = false;
      document.body.classList.remove("busy");
    }
  }

  type Mode =
    "menu" | "ready" | "playing" | "over" | "store" | "stats" | "help";
  type Pipe = {
    upper: Phaser.GameObjects.Image;
    lower: Phaser.GameObjects.Image;
    x: number;
    gapTop: number;
    gapBottom: number;
    scored: boolean;
  };

  let W = 390;
  let H = 844;
  let GROUND = H * (688 / 844);
  const PIPE_W = 86;
  let BIRD_X = W * (112 / 390);
  const assetUrl = (name: string) =>
    `${import.meta.env.BASE_URL}assets/sono/${name}`;
  function el<T extends HTMLElement = HTMLElement>(id: string): T {
    return document.getElementById(id) as T;
  }
  function setText(id: string, value: string | number): void {
    el(id).textContent = String(value);
  }

  const audio = new GameAudio();
  document.addEventListener("pointerdown", () => void audio.unlock(), {
    capture: true,
  });
  document.addEventListener("keydown", () => void audio.unlock(), {
    capture: true,
  });
  function beep(
    frequency: number,
    duration = 0.1,
    wave: OscillatorType = "sine",
  ): void {
    audio.effects = preferences.sound;
    audio.tone(frequency, duration, wave);
  }
  function show(mode: Mode): void {
    for (const id of ["menu", "ready", "game-over", "store", "stats", "help"])
      el(id).classList.add("hidden");
    const screenId = mode === "over" ? "game-over" : mode;
    if (mode !== "playing") el(screenId).classList.remove("hidden");
    el("hud").classList.toggle(
      "hidden",
      mode !== "ready" && mode !== "playing",
    );
    el("play-bank").classList.toggle(
      "hidden",
      mode !== "ready" && mode !== "playing",
    );
    setText("lives-count", save.lives);
    setText("best", save.best);
    setText("menu-coins", save.coins);
    setText("store-coins", save.coins);
    setText("ready-coins", save.lives);
    setText("stats-best", save.best);
    setText("stats-games", save.games);
    setText("stats-pipes", save.pipes);
    setText("stats-coins", save.coins);
    el("sound-button").textContent = preferences.sound ? "♪" : "×";
    el("sky").dataset.theme = save.selectedBackground;
    el("sky").dataset.mode = mode;
    if (mode === "store") renderStore();
  }

  function renderStore(): void {
    const list = el("skins");
    list.replaceChildren();
    for (const skin of SKINS.filter((s) => s.id !== "pilot")) {
      const card = document.createElement("div");
      card.className = "store-item";
      const preview = document.createElement("div");
      preview.className = `store-preview ${skin.id}`;
      const name = document.createElement("strong");
      name.textContent = skin.name;
      const price = document.createElement("span");
      price.className = "store-price";
      price.textContent = `${skin.cost} coins`;
      const button = document.createElement("button");
      button.className = "store-buy";
      const owned = save.owned.includes(skin.id);
      const selected = save.selected === skin.id;
      button.textContent = selected ? "USING" : owned ? "USE" : "BUY";
      button.disabled = selected || (!owned && save.coins < skin.cost);
      const requestId = crypto.randomUUID();
      button.addEventListener(
        "click",
        () =>
          void command(async () => {
            save = owned
              ? await gateway.equip("skin", skin.id)
              : await gateway.purchase("skin", skin.id, requestId);
            scene.setSkin();
            show("store");
            beep(660, 0.13);
          }),
      );
      card.append(preview, name, price, button);
      list.append(card);
    }
    const backgrounds = el("backgrounds");
    backgrounds.replaceChildren();
    for (const background of BACKGROUNDS.filter((b) => b.id !== "classic")) {
      const card = document.createElement("div");
      card.className = "store-item";
      const preview = document.createElement("div");
      preview.className = `store-preview ${background.imageClass}`;
      const name = document.createElement("strong");
      name.textContent = background.name;
      const price = document.createElement("span");
      price.className = "store-price";
      price.textContent = `${background.cost} coins`;
      const button = document.createElement("button");
      button.className = "store-buy";
      const owned = save.ownedBackgrounds.includes(background.id);
      const selected = save.selectedBackground === background.id;
      button.textContent = selected ? "USING" : owned ? "USE" : "BUY";
      button.disabled = selected || (!owned && save.coins < background.cost);
      const requestId = crypto.randomUUID();
      button.addEventListener(
        "click",
        () =>
          void command(async () => {
            save = owned
              ? await gateway.equip("background", background.id)
              : await gateway.purchase("background", background.id, requestId);
            show("store");
            beep(660, 0.13);
          }),
      );
      card.append(preview, name, price, button);
      backgrounds.append(card);
    }
  }

  class MainScene extends Phaser.Scene {
    mode: Mode = "menu";
    bird!: Phaser.GameObjects.Container;
    birdBody!: Phaser.GameObjects.Image;
    propeller!: Phaser.GameObjects.Ellipse;
    smoke: {
      shape: Phaser.GameObjects.Ellipse;
      age: number;
      vx: number;
      vy: number;
    }[] = [];
    pipes: Pipe[] = [];
    pipePool: Pipe[] = [];
    score = 0;
    runCoins = 0;
    velocity = 0;
    spawnTimer = 0;
    elapsed = 0;
    accumulator = 0;
    landscape!: Phaser.GameObjects.TileSprite;
    paused = false;
    runId = "";
    startRequestId = crypto.randomUUID();
    pendingFinish = false;
    startedAt = 0;
    taps: number[] = [];

    constructor() {
      super("Main");
    }

    preload(): void {
      this.load.image("bird-pilot", assetUrl("pilot.png"));
      if (save.selected !== "pilot") {
        this.load.image(
          `bird-${save.selected}`,
          assetUrl(`${save.selected}.png`),
        );
      }
      this.load.image("pipe", assetUrl("pipe.png"));
      for (const theme of ["game", "sunset", "city"])
        this.load.image(`land-${theme}`, assetUrl(`${theme}-background.webp`));
    }

    create(): void {
      // Mirrored image pairs make a continuous panorama without a hard repeat seam.
      for (const theme of ["game", "sunset", "city"]) {
        const canvas = this.textures.createCanvas(
          `panorama-${theme}`,
          W * 2,
          H,
        )!;
        const ctx = canvas.context;
        const source = this.textures
          .get(`land-${theme}`)
          .getSourceImage() as HTMLImageElement;
        ctx.drawImage(source, 0, 0, W, H);
        ctx.save();
        ctx.translate(W * 2, 0);
        ctx.scale(-1, 1);
        ctx.drawImage(source, 0, 0, W, H);
        ctx.restore();
        canvas.refresh();
      }
      this.landscape = this.add
        .tileSprite(0, 0, W, H, "panorama-game")
        .setOrigin(0)
        .setDepth(-1);
      // Remove transparent margins from the collision artwork at runtime.
      const source = this.textures
        .get("pipe")
        .getSourceImage() as HTMLImageElement;
      const canvas = document.createElement("canvas");
      canvas.width = source.width;
      canvas.height = source.height;
      const ctx = canvas.getContext("2d")!;
      ctx.drawImage(source, 0, 0);
      const pixels = ctx.getImageData(0, 0, source.width, source.height).data;
      let left = source.width,
        right = 0,
        top = source.height,
        bottom = 0;
      for (let y = 0; y < source.height; y++)
        for (let x = 0; x < source.width; x++) {
          if (pixels[(y * source.width + x) * 4 + 3] > 128) {
            left = Math.min(left, x);
            right = Math.max(right, x);
            top = Math.min(top, y);
            bottom = Math.max(bottom, y);
          }
        }
      this.textures
        .get("pipe")
        .add("trimmed", 0, left, top, right - left + 1, bottom - top + 1);

      this.birdBody = this.add.image(0, 0, `bird-${save.selected}`);
      this.setSkin();
      this.bird = this.add.container(BIRD_X, H * 0.48, [this.birdBody]);
      this.bird.setDepth(5);
      this.propeller = this.add.ellipse(29, 8, 5, 34, 0xe4f6ff, 0.72);
      const hub = this.add.circle(29, 8, 3, 0x60534a);
      this.bird.add([this.propeller, hub]);
      for (let i = 0; i < 18; i++)
        this.smoke.push({
          shape: this.add
            .ellipse(0, 0, 12, 12, 0x65707e)
            .setDepth(6)
            .setVisible(false),
          age: 2,
          vx: 0,
          vy: 0,
        });
      this.input.on("pointerdown", () => {
        if (document.querySelector(".dialog-backdrop:not(.hidden)")) return;
        if (this.mode === "ready") this.startRun();
        else if (this.mode === "playing") this.flap();
      });
      this.input.keyboard?.on("keydown-SPACE", (event: KeyboardEvent) => {
        event.preventDefault();
        if (document.querySelector(".dialog-backdrop:not(.hidden)")) return;
        if (this.mode === "ready") this.startRun();
        else if (this.mode === "playing") this.flap();
      });
      this.go("menu");
      el("loading").classList.add("hidden");
    }

    setSkin(): void {
      const key = `bird-${save.selected}`;
      if (!this.textures.exists(key)) {
        this.load.image(key, assetUrl(`${save.selected}.png`));
        this.load.once(Phaser.Loader.Events.COMPLETE, () => this.setSkin());
        this.load.start();
        return;
      }
      this.birdBody.setTexture(key).setDisplaySize(72, 72);
    }

    go(mode: Mode): void {
      this.mode = mode;
      if (!["over", "playing"].includes(mode))
        for (const puff of this.smoke) puff.shape.setVisible(false);
      this.landscape.setVisible(["ready", "playing", "over"].includes(mode));
      this.landscape.setTexture(
        `panorama-${save.selectedBackground === "classic" ? "game" : save.selectedBackground}`,
      );
      this.landscape.tileScaleY =
        H / this.landscape.texture.getSourceImage().height;
      this.bird.setVisible(
        mode === "ready" || mode === "playing" || mode === "over",
      );
      if (
        mode === "menu" ||
        mode === "store" ||
        mode === "stats" ||
        mode === "help"
      )
        this.clearPipes();
      if (mode === "ready") {
        this.clearPipes();
        this.bird.setPosition(BIRD_X, H * 0.55);
        this.bird.setRotation(0);
        setText("score", 0);
      }
      show(mode);
    }

    async startRun(): Promise<void> {
      if (this.mode === "playing") return;
      if (busy) return;
      busy = true;
      try {
        if (this.pendingFinish) await this.settleResult();
        const result = await gateway.startRun(this.startRequestId);
        this.startRequestId = crypto.randomUUID();
        this.runId = result.runId;
        save = result.snapshot;
      } catch (error) {
        if (error instanceof Error && error.message === "NO_LIVES") openLives();
        else report(error);
        return;
      } finally {
        busy = false;
      }
      this.startedAt = performance.now();
      this.taps = [];
      this.paused = false;
      this.clearPipes();
      this.score = 0;
      this.runCoins = 0;
      this.elapsed = 0;
      this.spawnTimer = 0.75;
      this.velocity = 0;
      this.bird.setPosition(BIRD_X, H * 0.48);
      this.bird.setRotation(0);

      setText("score", 0);
      this.go("playing");
      this.flap();
    }

    flap(): void {
      if (this.paused) return;
      void audio.unlock();
      if (this.taps.length < 20000)
        this.taps.push(Math.round(performance.now() - this.startedAt));
      this.velocity = -365;
      this.bird.setRotation(-0.25);
      beep(530, 0.07);
    }

    spawnPipe(): void {
      const gap = 185;
      const center = Phaser.Math.Between(
        Math.round(GROUND * 0.34),
        Math.round(GROUND * 0.67),
      );
      const top = center - gap / 2;
      const bottom = center + gap / 2;
      const x = W + 18;
      const pipe = this.pipePool.pop() ?? this.createPipe();
      const { upper, lower } = pipe;
      upper
        .setPosition(x + PIPE_W / 2, top / 2)
        .setDisplaySize(PIPE_W, top)
        .setVisible(true);
      const lowerHeight = GROUND - bottom;
      lower
        .setPosition(x + PIPE_W / 2, bottom + lowerHeight / 2)
        .setDisplaySize(PIPE_W, lowerHeight)
        .setVisible(true);
      Object.assign(pipe, { x, gapTop: top, gapBottom: bottom, scored: false });
      this.pipes.push(pipe);
    }

    createPipe(): Pipe {
      const upper = this.add
        .image(0, 0, "pipe", "trimmed")
        .setRotation(Math.PI)
        .setDepth(2);
      const lower = this.add.image(0, 0, "pipe", "trimmed").setDepth(2);
      return { upper, lower, x: 0, gapTop: 0, gapBottom: 0, scored: false };
    }

    recyclePipe(pipe: Pipe): void {
      pipe.upper.setVisible(false);
      pipe.lower.setVisible(false);
      this.pipePool.push(pipe);
    }

    clearPipes(): void {
      for (const pipe of this.pipes) this.recyclePipe(pipe);
      this.pipes.length = 0;
    }

    die(): void {
      if (this.mode !== "playing") return;
      this.mode = "over";

      setText("rank-value", save.lives);
      setText("final-score", this.score);
      setText("earned-coins", this.runCoins);
      audio.effects = preferences.sound;
      audio.crash();
      for (const puff of this.smoke) {
        puff.age = Math.random() * 0.25;
        puff.vx = Phaser.Math.Between(-38, 30);
        puff.vy = Phaser.Math.Between(-65, -25);
        puff.shape
          .setPosition(
            this.bird.x + Phaser.Math.Between(-12, 12),
            this.bird.y + 8,
          )
          .setVisible(true)
          .setAlpha(0.75)
          .setScale(0.4);
      }
      if (preferences.haptics) navigator.vibrate?.(40);
      this.go("over");
      setText("earned-coins", "…");
      this.pendingFinish = true;
      sessionStorage.setItem(
        "sono-pending-run",
        JSON.stringify({ id: this.runId, score: this.score, taps: this.taps }),
      );
      void command(() => this.settleResult());
    }

    async settleResult(): Promise<void> {
      const result = await gateway.finishRun(this.runId, this.score, this.taps);
      save = result.snapshot;
      this.runCoins = result.awardedCoins;
      this.pendingFinish = false;
      sessionStorage.removeItem("sono-pending-run");
      setText("earned-coins", this.runCoins);
      show("over");
    }

    update(_time: number, delta: number): void {
      this.accumulator += Math.min(delta, 100);
      while (this.accumulator >= 1000 / 120) {
        this.step(1 / 120);
        this.accumulator -= 1000 / 120;
      }
    }

    step(dt: number): void {
      audio.setActive(!document.hidden && !this.paused);
      if (this.paused) return;
      if (this.propeller) {
        this.propeller.setScale(
          1,
          this.mode === "over"
            ? 0.15
            : 0.2 + Math.abs(Math.sin(this.elapsed * 65)) * 0.8,
        );
        this.propeller.setAlpha(this.mode === "over" ? 0.35 : 0.7);
      }
      for (const puff of this.smoke) {
        if (!puff.shape.visible) continue;
        puff.age += dt;
        if (puff.age >= 1.8) {
          puff.shape.setVisible(false);
          continue;
        }
        puff.shape.x += puff.vx * dt;
        puff.shape.y += puff.vy * dt;
        puff.shape
          .setScale(0.4 + puff.age * 1.8)
          .setAlpha((1 - puff.age / 1.8) * 0.65);
      }
      this.elapsed += dt;
      if (this.mode === "ready") {
        this.bird.y = H * 0.55 + Math.sin(this.elapsed * 3.2) * 9;
        this.bird.angle = Math.sin(this.elapsed * 3.2) * 6;
        return;
      }
      if (this.mode !== "playing" || this.paused) return;
      this.landscape.tilePositionX += dt * 30;
      this.velocity += 980 * dt;
      this.bird.y += this.velocity * dt;
      this.bird.rotation = Phaser.Math.Clamp(this.velocity / 750, -0.36, 0.78);
      if (this.bird.y < 28) {
        this.bird.y = 28;
        this.velocity = 0;
      }
      if (this.bird.y + 21 >= GROUND - 12) {
        this.die();
        return;
      }
      this.spawnTimer -= dt;
      if (this.spawnTimer <= 0) {
        this.spawnPipe();
        this.spawnTimer = 1.65;
      }
      const speed = 145 + Math.min(this.score * 3, 45);
      for (const pipe of this.pipes) {
        pipe.x -= speed * dt;
        pipe.upper.x = pipe.x + PIPE_W / 2;
        pipe.lower.x = pipe.x + PIPE_W / 2;
        if (!pipe.scored && pipe.x + PIPE_W < BIRD_X - 10) {
          pipe.scored = true;
          this.score += 1;

          setText("score", this.score);
          setText("best", save.best);
          setText("ready-coins", save.lives);
          beep(760, 0.12);
        }
        const birdLeft = BIRD_X - 19;
        const birdRight = BIRD_X + 19;
        const birdTop = this.bird.y - 18;
        const birdBottom = this.bird.y + 18;
        if (
          birdRight > pipe.x + 5 &&
          birdLeft < pipe.x + PIPE_W - 5 &&
          (birdTop < pipe.gapTop || birdBottom > pipe.gapBottom)
        ) {
          this.die();
          return;
        }
      }
      for (let i = this.pipes.length - 1; i >= 0; i--) {
        const pipe = this.pipes[i];
        if (pipe.x + PIPE_W < -10) {
          this.recyclePipe(pipe);
          this.pipes.splice(i, 1);
        }
      }
    }
  }

  const scene = new MainScene();
  if (import.meta.env.DEV)
    Object.assign(window, { __SONO_DEV__: scene, __SONO_AUDIO__: audio });
  const game = new Phaser.Game({
    type: Phaser.AUTO,
    parent: "game-root",
    width: W,
    height: H,
    transparent: true,
    antialias: true,
    scene,
    render: { pixelArt: false },
  });

  function fit(): void {
    const stage = el("stage-wrap");
    const shell = el("game-shell");
    const padding = getComputedStyle(stage);
    const width =
      stage.clientWidth -
      parseFloat(padding.paddingLeft) -
      parseFloat(padding.paddingRight);
    const height =
      stage.clientHeight -
      parseFloat(padding.paddingTop) -
      parseFloat(padding.paddingBottom);
    if (width <= 0 || height <= 0) return;
    // Portrait fills the available width; wider screens extend the game world.
    // Both axes use ONE scale, so birds, circles and text are never stretched.
    const scale = Math.min(width / 390, height / 650);
    const oldW = W,
      oldH = H;
    W = width / scale;
    H = height / scale;
    GROUND = H * (688 / 844);
    BIRD_X = W * (112 / 390);
    shell.style.width = `${W}px`;
    shell.style.height = `${H}px`;
    shell.style.setProperty("--world-height", `${H}px`);
    shell.style.setProperty("--game-scale-x", String(scale));
    shell.style.setProperty("--game-scale-y", String(scale));
    game.scale.resize(W, H);
    if (scene.landscape) {
      scene.landscape.setSize(W, H);
      scene.landscape.tileScaleY =
        H / scene.landscape.texture.getSourceImage().height;
      scene.bird.setPosition(BIRD_X, (scene.bird.y * H) / oldH);
      for (const pipe of scene.pipes) {
        pipe.x *= W / oldW;
        pipe.gapTop *= H / oldH;
        pipe.gapBottom *= H / oldH;
        pipe.upper
          .setPosition(pipe.x + PIPE_W / 2, pipe.gapTop / 2)
          .setDisplaySize(PIPE_W, pipe.gapTop);
        const lowerHeight = GROUND - pipe.gapBottom;
        pipe.lower
          .setPosition(pipe.x + PIPE_W / 2, pipe.gapBottom + lowerHeight / 2)
          .setDisplaySize(PIPE_W, lowerHeight);
      }
    }
  }
  window.addEventListener("resize", fit);
  window.visualViewport?.addEventListener("resize", fit);
  new ResizeObserver(fit).observe(el("stage-wrap"));
  fit();

  el("play-button").addEventListener("click", () => scene.go("ready"));
  el("start-button").addEventListener("click", () => scene.startRun());
  el("retry-button").addEventListener("click", () => scene.startRun());
  el("home-button").addEventListener("click", () => scene.go("menu"));
  el("store-button").addEventListener("click", () => scene.go("store"));
  el("over-store-button").addEventListener("click", () => scene.go("store"));
  el("stats-button").addEventListener("click", () => scene.go("stats"));
  el("help-button").addEventListener("click", () => scene.go("help"));
  el("reset-look").onclick = () =>
    void command(async () => {
      save = await gateway.equip("skin", "pilot");
      save = await gateway.equip("background", "classic");
      scene.setSkin();
      show("store");
    });
  el("store-back").addEventListener("click", () => scene.go("menu"));
  el("stats-back").addEventListener("click", () => scene.go("menu"));
  el("help-back").addEventListener("click", () => scene.go("menu"));
  el("stats-play").addEventListener("click", () => scene.go("ready"));
  el("help-play").addEventListener("click", () => scene.go("ready"));
  el("sound-button").addEventListener("click", () => {
    preferences.sound = !preferences.sound;
    audio.effects = preferences.sound;
    localStorage.setItem("sono-sound", preferences.sound ? "on" : "off");
    show("menu");
  });

  function openLives(): void {
    scene.paused = scene.mode === "playing";
    el("life-dialog").classList.remove("hidden");
    setText("life-balance", save.coins);
    el("life-options").replaceChildren();
    for (const pack of LIFE_PACKS) {
      const button = document.createElement("button");
      button.className = "life-option";
      button.textContent = `✦ ${pack.cost} BONUS COINS     ♥ ${pack.lives}`;
      button.classList.toggle("selected", selectedPack === pack.id);
      button.onclick = () => {
        selectedPack = pack.id;
        openLives();
      };
      el("life-options").append(button);
    }
  }
  el("lives-button").addEventListener("click", openLives);
  el("life-close").addEventListener("click", () => {
    el("life-dialog").classList.add("hidden");
    scene.paused = false;
  });
  async function completeLifePurchase(): Promise<void> {
    await command(async () => {
      if (!lifeKeys.has(selectedPack))
        lifeKeys.set(selectedPack, crypto.randomUUID());
      save = await gateway.buyLives(selectedPack, lifeKeys.get(selectedPack)!);
      lifeKeys.delete(selectedPack);
      el("pin-dialog").classList.add("hidden");
      el("life-dialog").classList.add("hidden");
      show(scene.mode);
      setText(
        "success-message",
        `You now have ${save.lives} lives. Ready to fly!`,
      );
      el("success-dialog").classList.remove("hidden");
    });
  }
  el("buy-lives").addEventListener("click", () => {
    const pack = LIFE_PACKS.find((p) => p.id === selectedPack)!;
    if (save.coins < pack.cost) {
      report(new Error("Таны bonus оноо хүрэлцэхгүй байна."));
      return;
    }
    if (import.meta.env.VITE_DATA_MODE === "api") {
      void completeLifePurchase();
      return;
    }
    pin = "";
    renderPin();
    el("pin-dialog").classList.remove("hidden");
  });
  let pin = "";
  function renderPin(): void {
    setText("pin-dots", "●".repeat(pin.length) + "○".repeat(4 - pin.length));
  }
  for (const value of [
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "←",
    "0",
    "×",
  ]) {
    const button = document.createElement("button");
    button.textContent = value;
    button.onclick = () => {
      if (value === "×") {
        el("pin-dialog").classList.add("hidden");
        return;
      }
      if (value === "←") pin = pin.slice(0, -1);
      else if (pin.length < 4) pin += value;
      renderPin();
      if (pin.length === 4) {
        if (pin === "0000") void completeLifePurchase();
        else {
          pin = "";
          renderPin();
          report(new Error("Demo PIN: 0000"));
        }
      }
    };
    el("pin-keys").append(button);
  }
  el("success-close").onclick = () => {
    el("success-dialog").classList.add("hidden");
    scene.paused = false;
  };
  el("settings-button").onclick = () =>
    el("settings-dialog").classList.remove("hidden");
  el("settings-close").onclick = () =>
    el("settings-dialog").classList.add("hidden");
  el("settings-music").textContent = audio.music ? "♫ MUSIC ON" : "♫ MUSIC OFF";
  el("settings-music").onclick = () => {
    audio.setMusic(!audio.music);
    el("settings-music").textContent = audio.music
      ? "♫ MUSIC ON"
      : "♫ MUSIC OFF";
  };
  window.addEventListener("pagehide", () => audio.setActive(false));
  el("settings-sound").onclick = () => {
    preferences.sound = !preferences.sound;
    audio.effects = preferences.sound;
    localStorage.setItem("sono-sound", preferences.sound ? "on" : "off");
    setText("settings-sound", preferences.sound ? "♪ ON" : "♪ OFF");
    show(scene.mode);
  };
  el("settings-haptics").onclick = () => {
    preferences.haptics = !preferences.haptics;
    localStorage.setItem("sono-haptics", preferences.haptics ? "on" : "off");
    setText(
      "settings-haptics",
      preferences.haptics ? "HAPTICS ON" : "HAPTICS OFF",
    );
  };
  el("gifts-button").onclick = () =>
    void command(async () => {
      el("leader-list").replaceChildren();
      const rows =
        import.meta.env.VITE_DATA_MODE === "api"
          ? await fetch("/api/leaderboard", {
              credentials: "same-origin",
            }).then((r) => {
              if (!r.ok) throw new Error("Leaderboard unavailable");
              return r.json();
            })
          : (await import("./data/fixtures")).DEMO_LEADERS;
      for (const [i, row] of rows.entries()) {
        const line = document.createElement("div");
        line.className = "leader-row";
        line.textContent = `${String(i + 1).padStart(2, "0")}     ${row.name}     ${row.score}`;
        el("leader-list").append(line);
      }
      setText("your-best", save.best);
      el("gifts-dialog").classList.remove("hidden");
    });
  el("gifts-close").onclick = () => el("gifts-dialog").classList.add("hidden");
  el("play-bank").onclick = () => {
    if (scene.mode === "playing") {
      scene.paused = true;
    }
    openLives();
  };
  el("pause-button").addEventListener("click", () => {
    scene.paused = true;
    el("pause-dialog").classList.remove("hidden");
  });
  el("resume-button").addEventListener("click", () => {
    scene.paused = false;
    el("pause-dialog").classList.add("hidden");
  });
  document.addEventListener("visibilitychange", () => {
    audio.setActive(!document.hidden && !scene.paused);
    if (document.hidden && scene.mode === "playing") {
      scene.paused = true;
      el("pause-dialog").classList.remove("hidden");
    }
  });

  el("error-close").addEventListener("click", () =>
    el("error-dialog").classList.add("hidden"),
  );
}
void boot().catch((error) => {
  const loading = document.getElementById("loading")!;
  loading.textContent =
    error instanceof Error ? error.message : "Unable to load game";
  const retry = document.createElement("button");
  retry.textContent = "Retry";
  retry.onclick = () => location.reload();
  loading.append(retry);
});
