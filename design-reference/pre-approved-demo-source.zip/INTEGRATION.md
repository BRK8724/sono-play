# Sono Play frontend integration

Run `npm install` and `npm run dev`. Mock is the default. `VITE_DATA_MODE=api npm run build` produces the API-connected frontend. Deploy static files and `/api` under the same HTTPS origin. For a subpath use `npm run build -- --base=/sono/v1/`.

## Mock separation

- `src/data/fixtures.ts`: fake new player (1,000 bonus credits, 5 lives) and leaderboard.
- `src/data/mock.ts`: asynchronous browser-only game service, saved under `sono-play-mock-v4`. It demonstrates idempotent actions and uses Web Locks for concurrent tabs where available. This is not a server or an anti-cheat implementation.
- `src/data/contracts.ts`: shared DTOs and `GameGateway` interface.
- `src/data/gateway.ts`: HTTP adapter; API mode never silently falls back to fake data.
- `src/data/catalog.ts`: display catalog and demo pack prices. Backend must own actual prices and keep the display catalog version aligned when deploying.

Delete `sono-play-mock-v4` from localStorage to reset the test account. The demo PIN is `0000`; it is a UI preview, never a real credential, and is bypassed in API mode. Real step-up approval belongs in the Flutter host/core and must be bound to the purchase order if core policy requires it.

## Host session

API mode first calls `GET /api/bootstrap` with the existing HttpOnly session cookie. On 401 it waits up to 15 seconds for `window.SonoPlayHost.launch(assertion)`. Flutter must verify the active game origin before calling this with a short-lived Play-only signed assertion. The game posts it to `/api/session/exchange`; the Play server verifies signature, issuer, audience, expiry and one-time jti and creates its HttpOnly, Secure, SameSite cookie. Never supply a core access token or a real PIN. `sono:host-ready` is a window event for a host wrapper; Flutter may also inject the assertion after page load. Actual Flutter production wiring is not in this standalone repository.

## HTTP contract

All mutations require authenticated ownership checks and Origin/CSRF enforcement server-side. Idempotency keys must be persisted server-side; reuse with a different payload must be rejected. The DTO shape is defined in `contracts.ts`.

| Request | Body | Response |
| --- | --- | --- |
| GET `/api/bootstrap` | — | `PlayerSnapshot` snapshot |
| POST `/api/session/exchange` | `{assertion}` | JSON acknowledgement + session cookie |
| POST `/api/runs/start` | `{}`; Idempotency-Key | `{runId,snapshot}` |
| POST `/api/runs/:id/finish` | `{score,taps}`; key `finish:<runId>` | `{snapshot,awardedCoins}` |
| POST `/api/orders` | `{kind,itemId}`; Idempotency-Key | `PlayerSnapshot` |
| POST `/api/inventory/equip` | `{kind,itemId}` | `PlayerSnapshot` |
| POST `/api/lives/purchase` | `{packId}`; Idempotency-Key | `PlayerSnapshot` |
| GET `/api/leaderboard` | — | `[{name,score}]` |

Current display pack IDs are `one`, `five`, `twelve` (100/400/900 demo credits). Real core SP transactions are not implemented in this frontend. The Play backend must validate gameplay, calculate bonus, atomically debit credits/grant lives, and settle real SP through core as described in the architecture docs. Frontend-reported scores and taps are untrusted evidence.

## Gameplay and demo rules

One run consumes one life. Finished runs earn 10 demo credits per pipe capped at 60, so a run cannot fund its own cheapest extra life. Demo energy regenerates one life per 10 minutes up to five when the mock service is accessed. Bought lives may exceed five, up to 99. The game pauses when backgrounded; screen overlays cannot trigger gameplay input. Death submits one result, with a pending result kept in sessionStorage for reload recovery. The scene uses a 120 Hz fixed simulation step, pooled obstacles, and mirrored scrolling panoramas. No network calls or storage writes occur per pipe or per frame.

## Verification performed

`npm run build` passes. `scripts/verify-browser.js` runs against Vite in a browser and checks initial fixtures, duplicate start, duplicate finish/capped reward, atomic/idempotent life purchase, insufficient balance, unowned skin rejection, and duplicate cosmetic purchase. Mobile Chromium navigation was checked for Store, Stats, Help, Settings, Gifts, life purchase/demo PIN/success. A six-second flight check confirmed moving scenery, scoring, pooled pipes, and bottom pipe bases at the ground boundary. No console errors were found in that check.

Physical iOS/Android WebView performance, core authentication, backend validation, real SP settlement, and 200k-user load testing remain integration release gates. A clean local build does not establish those guarantees.

## Flight effects and responsive verification

`src/audio/GameAudio.ts` generates an original gentle flight melody, bass accompaniment and filtered-noise crash effect through Web Audio. Audio starts after a user gesture, music and effects have separate controls, and audio suspends while paused/hidden. Propeller animation and 18 reusable smoke objects are scene-local and make no server requests.

Chromium viewport checks passed at 320×568, 390×844, 430×932 and 844×390: the game shell and settings card stayed inside the viewport. A subsequent regression check verified that the shell fills both viewport dimensions at 320×568, 375×667, 390×844, 430×932 and 844×390, rather than merely fitting inside them. The logical game world resizes to fill the available viewport; a uniform scale preserves sprite and text proportions. Landscape extends the world width. Safe-area padding and dynamic viewport height are supported. Real iOS/Android WebView audio policies and safe-area insets still require device testing.
