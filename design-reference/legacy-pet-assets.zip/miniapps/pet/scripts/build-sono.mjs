import * as THREE from "three";
import { GLTFExporter } from "three/addons/exporters/GLTFExporter.js";
import { writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

// Asset generator for Sono. Keep it in the repository so the rig and clips can
// be rebuilt and refined without an external DCC project.
globalThis.FileReader ??= class {
  result = null;
  onloadend = null;
  async readAsArrayBuffer(blob) {
    this.result = await blob.arrayBuffer();
    this.onloadend?.();
  }
};

const scene = new THREE.Scene();
const rig = new THREE.Group();
rig.name = "Sono_Rig";
scene.add(rig);
const material = (color, roughness = 0.65, metalness = 0) =>
  new THREE.MeshStandardMaterial({ color, roughness, metalness });
const purple = material(0x7944bf, 0.55);
const purpleLight = material(0xaa80e7, 0.58);
const purpleDark = material(0x52348d, 0.7);
const orange = material(0xf09b23, 0.48);
const orangeDark = material(0xc86b21, 0.66);
const green = material(0x58bf5d, 0.6);
const white = material(0xfffcfa, 0.44);
const iris = material(0x6541a8, 0.35);
const pupil = material(0x17182b, 0.18);
const shine = new THREE.MeshBasicMaterial({ color: 0xffffff });

function ellipsoid(parent, name, mat, position, scale, segments = 24) {
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(1, segments, 16), mat);
  mesh.name = name;
  mesh.position.set(...position);
  mesh.scale.set(...scale);
  parent.add(mesh);
  return mesh;
}
function bone(parent, name, position) {
  const result = new THREE.Bone();
  result.name = name;
  result.position.set(...position);
  parent.add(result);
  return result;
}
function curvedBeak() {
  const rings = [
    [0.61, -0.23, 0.22, 0.12],
    [0.78, -0.28, 0.25, 0.16],
    [1.0, -0.38, 0.18, 0.12],
    [1.21, -0.53, 0.018, 0.02],
  ];
  const vertices = [];
  const indices = [];
  const steps = 20;
  for (const [z, y, rx, ry] of rings) {
    for (let i = 0; i < steps; i++) {
      const angle = (i / steps) * Math.PI * 2;
      vertices.push(Math.cos(angle) * rx, y + Math.sin(angle) * ry, z);
    }
  }
  for (let r = 0; r < rings.length - 1; r++) {
    for (let i = 0; i < steps; i++) {
      const a = r * steps + i;
      const b = r * steps + ((i + 1) % steps);
      indices.push(a, b, a + steps, b, b + steps, a + steps);
    }
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute(
    "position",
    new THREE.Float32BufferAttribute(vertices, 3),
  );
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  const mesh = new THREE.Mesh(geometry, orange);
  mesh.name = "UpperBeak";
  return mesh;
}

const root = bone(rig, "SonoRoot", [0, 0, 0]);
const body = bone(root, "Body", [0, 0, 0]);
const head = bone(body, "Head", [0, 2.13, 0]);
const tail = bone(body, "Tail", [0, 0.68, -0.51]);
const wingL = bone(body, "Wing_L", [-0.57, 1.43, -0.02]);
const wingR = bone(body, "Wing_R", [0.57, 1.43, -0.02]);
const wingTipL = bone(wingL, "WingTip_L", [-0.17, -0.51, 0]);
const wingTipR = bone(wingR, "WingTip_R", [0.17, -0.51, 0]);
const legL = bone(body, "Leg_L", [-0.24, 0.17, 0.03]);
const legR = bone(body, "Leg_R", [0.24, 0.17, 0.03]);

ellipsoid(body, "BodyMesh", purple, [0, 1.1, 0], [0.67, 0.92, 0.56], 32);
ellipsoid(head, "HeadMesh", purple, [0, 0, 0], [0.82, 0.77, 0.7], 36);
ellipsoid(
  head,
  "Cheek_L",
  purpleLight,
  [-0.47, -0.27, 0.48],
  [0.23, 0.17, 0.09],
);
ellipsoid(
  head,
  "Cheek_R",
  purpleLight,
  [0.47, -0.27, 0.48],
  [0.23, 0.17, 0.09],
);

for (const sign of [-1, 1]) {
  const eyes = new THREE.Group();
  eyes.name = sign < 0 ? "Eyes_L" : "Eyes_R";
  eyes.position.set(sign * 0.29, 0.12, 0.58);
  head.add(eyes);
  ellipsoid(eyes, `${eyes.name}_White`, white, [0, 0, 0], [0.23, 0.27, 0.11]);
  ellipsoid(
    eyes,
    `${eyes.name}_Iris`,
    iris,
    [-0.02, -0.05, 0.105],
    [0.13, 0.16, 0.052],
  );
  ellipsoid(
    eyes,
    `${eyes.name}_Pupil`,
    pupil,
    [-0.02, -0.06, 0.147],
    [0.086, 0.11, 0.03],
  );
  ellipsoid(
    eyes,
    `${eyes.name}_Shine`,
    shine,
    [-0.065, 0.01, 0.174],
    [0.035, 0.045, 0.012],
    12,
  );
  const brow = ellipsoid(
    head,
    `Brow_${sign < 0 ? "L" : "R"}`,
    purpleDark,
    [sign * 0.29, 0.45, 0.52],
    [0.25, 0.038, 0.05],
  );
  brow.rotation.z = sign * -0.12;
}
head.add(curvedBeak());
ellipsoid(head, "MouthInterior", pupil, [0, -0.43, 0.69], [0.16, 0.11, 0.09]);
ellipsoid(head, "LowerBeak", orangeDark, [0, -0.52, 0.79], [0.18, 0.07, 0.2]);
const tuftA = ellipsoid(
  head,
  "Tuft_L",
  purple,
  [-0.11, 0.74, -0.03],
  [0.17, 0.34, 0.18],
);
tuftA.rotation.z = -0.45;
const tuftB = ellipsoid(
  head,
  "Tuft_R",
  purpleLight,
  [0.1, 0.68, -0.06],
  [0.13, 0.28, 0.14],
);
tuftB.rotation.z = 0.75;

// Each wing is a skinned mesh. Top vertices follow the shoulder bone; lower
// vertices blend into the tip bone for a soft bend during action clips.
for (const [sign, shoulder, tip] of [
  [-1, wingL, wingTipL],
  [1, wingR, wingTipR],
]) {
  const geometry = new THREE.SphereGeometry(1, 24, 18);
  geometry.scale(0.23, 0.59, 0.3);
  geometry.translate(sign * 0.73, 1.18, 0.03);
  const positions = geometry.getAttribute("position");
  const indices = [];
  const weights = [];
  for (let i = 0; i < positions.count; i++) {
    const y = positions.getY(i);
    const tipWeight = THREE.MathUtils.smoothstep(1.52 - y, 0.08, 0.82) * 0.8;
    indices.push(0, 1, 0, 0);
    weights.push(1 - tipWeight, tipWeight, 0, 0);
  }
  geometry.setAttribute(
    "skinIndex",
    new THREE.Uint16BufferAttribute(indices, 4),
  );
  geometry.setAttribute(
    "skinWeight",
    new THREE.Float32BufferAttribute(weights, 4),
  );
  const mesh = new THREE.SkinnedMesh(geometry, purple);
  mesh.name = sign < 0 ? "WingMesh_L" : "WingMesh_R";
  rig.add(mesh);
  rig.updateMatrixWorld(true);
  mesh.bind(new THREE.Skeleton([shoulder, tip]));
  ellipsoid(
    tip,
    sign < 0 ? "WingFeather_L" : "WingFeather_R",
    purpleLight,
    [sign * 0.08, -0.11, 0.05],
    [0.14, 0.22, 0.22],
  );
}

for (const [sign, leg] of [
  [-1, legL],
  [1, legR],
]) {
  ellipsoid(leg, `Shin_${sign}`, orange, [0, -0.02, 0], [0.09, 0.42, 0.09]);
  ellipsoid(leg, `Foot_${sign}`, orange, [0, -0.45, 0.22], [0.19, 0.105, 0.31]);
  for (let toe = -1; toe <= 1; toe++)
    ellipsoid(
      leg,
      `Toe_${sign}_${toe}`,
      orange,
      [toe * 0.12, -0.49, 0.45],
      [0.084, 0.08, 0.18],
      16,
    );
}
for (let i = -1; i <= 1; i++) {
  const feather = ellipsoid(
    tail,
    `TailFeather_${i}`,
    green,
    [i * 0.33, -0.02, 0],
    [0.16, 0.46, 0.15],
  );
  feather.rotation.z = -i * 0.6;
  feather.rotation.x = -0.5;
}

const q = (x = 0, y = 0, z = 0) =>
  new THREE.Quaternion().setFromEuler(new THREE.Euler(x, y, z)).toArray();
const quat = (name, times, eulers) =>
  new THREE.QuaternionKeyframeTrack(
    `${name}.quaternion`,
    times,
    eulers.flatMap((v) => q(...v)),
  );
const vec = (name, property, times, values) =>
  new THREE.VectorKeyframeTrack(`${name}.${property}`, times, values.flat());
const clip = (name, duration, tracks) =>
  new THREE.AnimationClip(name, duration, tracks);
const eyes = (times, heights) => [
  vec(
    "Eyes_L",
    "scale",
    times,
    heights.map((y) => [1, y, 1]),
  ),
  vec(
    "Eyes_R",
    "scale",
    times,
    heights.map((y) => [1, y, 1]),
  ),
];
const clips = [
  clip("idle", 4, [
    quat(
      "Head",
      [0, 1, 2, 3, 4],
      [
        [0, 0, 0],
        [0.02, -0.045, 0.025],
        [0, 0, 0],
        [-0.02, 0.045, -0.025],
        [0, 0, 0],
      ],
    ),
    quat(
      "Wing_L",
      [0, 2, 4],
      [
        [0, 0, 0],
        [0, 0, -0.09],
        [0, 0, 0],
      ],
    ),
    quat(
      "Wing_R",
      [0, 2, 4],
      [
        [0, 0, 0],
        [0, 0, 0.09],
        [0, 0, 0],
      ],
    ),
    vec(
      "Body",
      "position",
      [0, 2, 4],
      [
        [0, 0, 0],
        [0, 0.035, 0],
        [0, 0, 0],
      ],
    ),
    ...eyes([0, 2.65, 2.77, 2.88, 4], [1, 1, 0.08, 1, 1]),
  ]),
  clip("pet", 1.5, [
    quat(
      "Head",
      [0, 0.45, 0.95, 1.5],
      [
        [0, 0, 0],
        [0.02, 0, -0.18],
        [-0.02, 0, 0.1],
        [0, 0, 0],
      ],
    ),
    quat(
      "Wing_L",
      [0, 0.7, 1.5],
      [
        [0, 0, 0],
        [0, 0, -0.35],
        [0, 0, 0],
      ],
    ),
    quat(
      "Wing_R",
      [0, 0.7, 1.5],
      [
        [0, 0, 0],
        [0, 0, 0.35],
        [0, 0, 0],
      ],
    ),
    ...eyes([0, 0.45, 0.7, 1.5], [1, 0.15, 1, 1]),
  ]),
  clip("wave", 1.6, [
    quat(
      "Wing_R",
      [0, 0.3, 0.55, 0.8, 1.05, 1.3, 1.6],
      [
        [0, 0, 0],
        [0, 0, 1.1],
        [0, 0, 0.8],
        [0, 0, 1.15],
        [0, 0, 0.8],
        [0, 0, 1.05],
        [0, 0, 0],
      ],
    ),
    quat(
      "Head",
      [0, 0.8, 1.6],
      [
        [0, 0, 0],
        [0, 0, -0.08],
        [0, 0, 0],
      ],
    ),
  ]),
  clip("play", 1.9, [
    quat(
      "Wing_L",
      [0, 0.3, 0.7, 1.1, 1.5, 1.9],
      [
        [0, 0, 0],
        [0, 0, -0.7],
        [0, 0, -0.2],
        [0, 0, -0.8],
        [0, 0, -0.25],
        [0, 0, 0],
      ],
    ),
    quat(
      "Wing_R",
      [0, 0.3, 0.7, 1.1, 1.5, 1.9],
      [
        [0, 0, 0],
        [0, 0, 0.7],
        [0, 0, 0.2],
        [0, 0, 0.8],
        [0, 0, 0.25],
        [0, 0, 0],
      ],
    ),
    vec(
      "SonoRoot",
      "position",
      [0, 0.3, 0.6, 0.95, 1.25, 1.6, 1.9],
      [
        [0, 0, 0],
        [0, 0.11, 0],
        [0, 0, 0],
        [0, 0.16, 0],
        [0, 0, 0],
        [0, 0.09, 0],
        [0, 0, 0],
      ],
    ),
    quat(
      "Head",
      [0, 0.95, 1.9],
      [
        [0, 0, 0],
        [-0.08, 0, 0],
        [0, 0, 0],
      ],
    ),
  ]),
  clip("feed", 1.9, [
    quat(
      "Head",
      [0, 0.4, 0.7, 1.0, 1.3, 1.6, 1.9],
      [
        [0, 0, 0],
        [0.14, 0, 0],
        [-0.1, 0, 0],
        [0.13, 0, 0],
        [-0.08, 0, 0],
        [0.1, 0, 0],
        [0, 0, 0],
      ],
    ),
    vec(
      "LowerBeak",
      "position",
      [0, 0.45, 0.65, 0.9, 1.1, 1.4, 1.9],
      [
        [0, -0.52, 0.79],
        [0, -0.63, 0.79],
        [0, -0.52, 0.79],
        [0, -0.63, 0.79],
        [0, -0.52, 0.79],
        [0, -0.59, 0.79],
        [0, -0.52, 0.79],
      ],
    ),
    quat(
      "Wing_L",
      [0, 0.7, 1.9],
      [
        [0, 0, 0],
        [0, 0, -0.35],
        [0, 0, 0],
      ],
    ),
  ]),
  clip("wash", 2.7, [
    quat(
      "Wing_L",
      [0, 0.45, 0.9, 1.35, 1.8, 2.25, 2.7],
      [
        [0, 0, 0],
        [0, 0, -0.6],
        [0, 0, -0.2],
        [0, 0, -0.6],
        [0, 0, -0.2],
        [0, 0, -0.6],
        [0, 0, 0],
      ],
    ),
    quat(
      "Wing_R",
      [0, 0.45, 0.9, 1.35, 1.8, 2.25, 2.7],
      [
        [0, 0, 0],
        [0, 0, 0.2],
        [0, 0, 0.6],
        [0, 0, 0.2],
        [0, 0, 0.6],
        [0, 0, 0.2],
        [0, 0, 0],
      ],
    ),
    quat(
      "Head",
      [0, 0.7, 1.4, 2.1, 2.7],
      [
        [0, 0, 0],
        [0, 0, -0.07],
        [0, 0, 0.07],
        [0, 0, -0.07],
        [0, 0, 0],
      ],
    ),
    ...eyes([0, 1.2, 1.35, 2.7], [1, 1, 0.15, 1]),
  ]),
  clip("sleep", 1.5, [
    quat(
      "Head",
      [0, 1.5],
      [
        [0, 0, 0],
        [0.1, 0, -0.15],
      ],
    ),
    ...eyes([0, 1.5], [1, 0.08]),
    quat(
      "Wing_L",
      [0, 1.5],
      [
        [0, 0, 0],
        [0, 0, -0.18],
      ],
    ),
    quat(
      "Wing_R",
      [0, 1.5],
      [
        [0, 0, 0],
        [0, 0, 0.18],
      ],
    ),
  ]),
  clip("sleepIdle", 3, [
    quat(
      "Head",
      [0, 1.5, 3],
      [
        [0.1, 0, -0.15],
        [0.08, 0, -0.13],
        [0.1, 0, -0.15],
      ],
    ),
    ...eyes([0, 3], [0.08, 0.08]),
    vec(
      "Body",
      "position",
      [0, 1.5, 3],
      [
        [0, 0, 0],
        [0, 0.018, 0],
        [0, 0, 0],
      ],
    ),
  ]),
  clip("wake", 1.5, [
    quat(
      "Head",
      [0, 0.65, 1.5],
      [
        [0.1, 0, -0.15],
        [-0.14, 0, 0.06],
        [0, 0, 0],
      ],
    ),
    quat(
      "Wing_L",
      [0, 0.7, 1.5],
      [
        [0, 0, -0.18],
        [0, 0, -0.7],
        [0, 0, 0],
      ],
    ),
    quat(
      "Wing_R",
      [0, 0.7, 1.5],
      [
        [0, 0, 0.18],
        [0, 0, 0.7],
        [0, 0, 0],
      ],
    ),
    ...eyes([0, 0.7, 1.5], [0.08, 1.15, 1]),
  ]),
  clip("walk", 1.2, [
    quat(
      "Leg_L",
      [0, 0.3, 0.6, 0.9, 1.2],
      [
        [0, 0, 0],
        [0.42, 0, 0],
        [0, 0, 0],
        [-0.42, 0, 0],
        [0, 0, 0],
      ],
    ),
    quat(
      "Leg_R",
      [0, 0.3, 0.6, 0.9, 1.2],
      [
        [0, 0, 0],
        [-0.42, 0, 0],
        [0, 0, 0],
        [0.42, 0, 0],
        [0, 0, 0],
      ],
    ),
    vec(
      "SonoRoot",
      "position",
      [0, 0.3, 0.6, 0.9, 1.2],
      [
        [0, 0, 0],
        [0, 0.075, 0],
        [0, 0, 0],
        [0, 0.075, 0],
        [0, 0, 0],
      ],
    ),
    quat(
      "Head",
      [0, 0.6, 1.2],
      [
        [0, 0, 0],
        [0, 0.06, 0],
        [0, 0, 0],
      ],
    ),
  ]),
  clip("equip", 1.9, [
    quat(
      "SonoRoot",
      [0, 0.5, 1.0, 1.5, 1.9],
      [
        [0, 0, 0],
        [0, 0.5, 0],
        [0, 0, -0.12],
        [0, -0.5, 0],
        [0, 0, 0],
      ],
    ),
    quat(
      "Wing_L",
      [0, 0.95, 1.9],
      [
        [0, 0, 0],
        [0, 0, -0.55],
        [0, 0, 0],
      ],
    ),
    quat(
      "Wing_R",
      [0, 0.95, 1.9],
      [
        [0, 0, 0],
        [0, 0, 0.55],
        [0, 0, 0],
      ],
    ),
  ]),
];

scene.updateMatrixWorld(true);
const exporter = new GLTFExporter();
const result = await exporter.parseAsync(scene, {
  binary: true,
  trs: true,
  animations: clips,
  onlyVisible: false,
  copyright: "Sono original character demo",
});
const output = resolve(
  dirname(fileURLToPath(import.meta.url)),
  "../public/assets/sono-rig.glb",
);
await writeFile(output, Buffer.from(result));
console.log(
  `Wrote ${output} (${Math.round(result.byteLength / 1024)} KiB, ${clips.length} clips)`,
);
