import {
  MiniAppSdk,
  type PetAction,
  type PetState,
} from "@pocketwise/miniapp-sdk";

const storageKey = "sono-pet-preview-v1";
const clamp = (n: number) => Math.max(0, Math.min(100, n));
function initial(): PetState {
  return {
    name: "Sono",
    satiety: 70,
    energy: 70,
    cleanliness: 70,
    happiness: 70,
    outfit: "none",
    room: "living",
    sleeping: false,
    updatedAt: new Date().toISOString(),
    demo: true,
  };
}
function advance(state: PetState): PetState {
  const minutes = Math.min(
    720,
    Math.max(0, Math.floor((Date.now() - Date.parse(state.updatedAt)) / 60000)),
  );
  if (!minutes) return state;
  const energy = clamp(
    state.energy + (state.sleeping ? minutes : -Math.floor(minutes / 20)),
  );
  return {
    ...state,
    satiety: clamp(state.satiety - Math.floor(minutes / 15)),
    energy,
    cleanliness: clamp(state.cleanliness - Math.floor(minutes / 25)),
    happiness: clamp(state.happiness - Math.floor(minutes / 20)),
    sleeping: state.sleeping && energy < 100,
    updatedAt: new Date().toISOString(),
  };
}
function localAction(
  state: PetState,
  action: PetAction,
  item?: string,
): PetState {
  const s = advance(state);
  const awake = () => {
    if (s.sleeping) throw new Error("Wake Sono first");
  };
  const room = (expected: PetState["room"]) => {
    if (s.room !== expected) throw new Error(`Go to the ${expected} first`);
  };
  let next: PetState;
  switch (action) {
    case "room":
      awake();
      if (!["living", "kitchen", "bedroom", "bathroom"].includes(item ?? ""))
        throw new Error("Unknown room");
      next = { ...s, room: item as PetState["room"] };
      break;
    case "feed":
      awake();
      room("kitchen");
      if (s.satiety >= 95) throw new Error("Sono is full");
      if (
        !item ||
        !({ apple: 1, berries: 1, toast: 1 } as Record<string, number>)[item]
      )
        throw new Error("Unknown food");
      next = {
        ...s,
        satiety: clamp(
          s.satiety +
            ({ apple: 17, berries: 12, toast: 22 } as Record<string, number>)[
              item
            ],
        ),
        cleanliness: clamp(s.cleanliness - 2),
        happiness: clamp(s.happiness + 3),
      };
      break;
    case "play":
      awake();
      room("living");
      if (!["ball", "bubbles", "blocks"].includes(item ?? ""))
        throw new Error("Unknown toy");
      if (s.energy < 12 || s.satiety < 10)
        throw new Error("Sono needs food or rest first");
      next = {
        ...s,
        energy: clamp(s.energy - 10),
        satiety: clamp(s.satiety - 4),
        cleanliness: clamp(s.cleanliness - 4),
        happiness: clamp(s.happiness + 16),
      };
      break;
    case "wash":
      awake();
      room("bathroom");
      if (s.cleanliness >= 95) throw new Error("Sono is already clean");
      next = {
        ...s,
        cleanliness: clamp(s.cleanliness + 45),
        happiness: clamp(s.happiness + 4),
      };
      break;
    case "sleep":
      room("bedroom");
      if (s.sleeping) throw new Error("Sono is already asleep");
      if (s.energy >= 95) throw new Error("Sono is not tired yet");
      next = { ...s, sleeping: true };
      break;
    case "wake":
      if (!s.sleeping) throw new Error("Sono is already awake");
      next = { ...s, sleeping: false };
      break;
    case "equip":
      awake();
      room("bedroom");
      if (!["none", "scarf", "hoodie", "sunglasses"].includes(item ?? ""))
        throw new Error("Unknown outfit");
      next = {
        ...s,
        outfit: item as PetState["outfit"],
        happiness: clamp(s.happiness + 2),
      };
      break;
  }
  return { ...next, updatedAt: new Date().toISOString() };
}

export class PetStore {
  private sdk = new MiniAppSdk("pet");
  readonly embedded: boolean;
  private constructor(embedded: boolean) {
    this.embedded = embedded;
  }
  static async create() {
    if (window.PocketwiseBridge) {
      const started = Date.now();
      while (!window.__POCKETWISE_NONCE__ && Date.now() - started < 10000)
        await new Promise((r) => setTimeout(r, 100));
    }
    return new PetStore(
      Boolean(window.__POCKETWISE_NONCE__ && window.PocketwiseBridge),
    );
  }
  async get(): Promise<PetState> {
    if (this.embedded) return this.sdk.petState();
    const raw = localStorage.getItem(storageKey);
    let state = initial();
    if (raw) {
      try {
        state = { ...state, ...JSON.parse(raw) };
      } catch {
        /* reset corrupt preview */
      }
    }
    state = advance(state);
    localStorage.setItem(storageKey, JSON.stringify(state));
    return state;
  }
  async meta() {
    return this.sdk.petMeta();
  }
  async act(action: PetAction, item?: string): Promise<PetState> {
    if (this.embedded) return this.sdk.petAction(action, item);
    const state = localAction(await this.get(), action, item);
    localStorage.setItem(storageKey, JSON.stringify(state));
    return state;
  }
}
