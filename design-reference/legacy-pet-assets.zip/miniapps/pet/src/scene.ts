import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import type { PetOutfit, PetRoom } from "@pocketwise/miniapp-sdk";

export type SceneInteraction =
  "character" | "play" | "feed" | "sleep" | "wash" | "window";

const purple = new THREE.MeshPhysicalMaterial({
  color: 0x7b47c4,
  roughness: 0.68,
  clearcoat: 0.05,
});
const purpleLight = new THREE.MeshStandardMaterial({
  color: 0xa779e7,
  roughness: 0.7,
});
const purpleDark = new THREE.MeshStandardMaterial({
  color: 0x53358b,
  roughness: 0.75,
});
const orange = new THREE.MeshPhysicalMaterial({
  color: 0xe99022,
  roughness: 0.52,
  clearcoat: 0.08,
});
const orangeDark = new THREE.MeshStandardMaterial({
  color: 0xcd6c1b,
  roughness: 0.7,
});
const green = new THREE.MeshStandardMaterial({
  color: 0x68c45a,
  roughness: 0.65,
});
const white = new THREE.MeshStandardMaterial({
  color: 0xfffaf6,
  roughness: 0.5,
});
const iris = new THREE.MeshStandardMaterial({
  color: 0x513289,
  roughness: 0.3,
});
const black = new THREE.MeshStandardMaterial({
  color: 0x18162f,
  roughness: 0.18,
});

function sphere(
  parent: THREE.Object3D,
  material: THREE.Material,
  pos: [number, number, number],
  scale: [number, number, number],
  segments = 24,
) {
  const mesh = new THREE.Mesh(
    new THREE.SphereGeometry(1, segments, Math.max(12, segments / 2)),
    material,
  );
  mesh.position.set(...pos);
  mesh.scale.set(...scale);
  parent.add(mesh);
  return mesh;
}
function box(
  parent: THREE.Object3D,
  color: number,
  pos: [number, number, number],
  scale: [number, number, number],
  radius = 0,
) {
  const mesh = new THREE.Mesh(
    new THREE.BoxGeometry(...scale),
    new THREE.MeshStandardMaterial({ color, roughness: 0.82 }),
  );
  mesh.position.set(...pos);
  mesh.rotation.z = radius;
  parent.add(mesh);
  return mesh;
}

function curvedBeak() {
  const geometry = new THREE.BufferGeometry();
  const rings = [
    [0.62, -0.23, 0.2, 0.1],
    [0.78, -0.29, 0.25, 0.16],
    [1.01, -0.39, 0.18, 0.12],
    [1.2, -0.53, 0.018, 0.02],
  ];
  const vertices: number[] = [],
    indices: number[] = [],
    steps = 18;
  for (const [z, y, rx, ry] of rings) {
    for (let i = 0; i < steps; i++) {
      const angle = (i / steps) * Math.PI * 2;
      vertices.push(Math.cos(angle) * rx, y + Math.sin(angle) * ry, z);
    }
  }
  for (let ring = 0; ring < rings.length - 1; ring++) {
    for (let i = 0; i < steps; i++) {
      const a = ring * steps + i,
        b = ring * steps + ((i + 1) % steps);
      indices.push(a, b, a + steps, b, b + steps, a + steps);
    }
  }
  geometry.setAttribute(
    "position",
    new THREE.Float32BufferAttribute(vertices, 3),
  );
  geometry.setIndex(indices);
  geometry.computeVertexNormals();
  return new THREE.Mesh(geometry, orange);
}

function makeDirtTexture() {
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = 128;
  const context = canvas.getContext("2d")!;
  const gradient = context.createRadialGradient(64, 64, 5, 64, 64, 62);
  gradient.addColorStop(0, "rgba(94, 63, 37, .72)");
  gradient.addColorStop(0.45, "rgba(112, 78, 47, .48)");
  gradient.addColorStop(1, "rgba(112, 78, 47, 0)");
  context.fillStyle = gradient;
  context.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 36; i++) {
    const angle = i * 2.39996;
    const radius = Math.sqrt((i + 0.5) / 36) * 52;
    context.beginPath();
    context.arc(
      64 + Math.cos(angle) * radius,
      64 + Math.sin(angle) * radius * 0.75,
      1.5 + (i % 4) * 0.9,
      0,
      Math.PI * 2,
    );
    context.fillStyle = i % 3 === 0 ? "#744f3977" : "#9c745988";
    context.fill();
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

export class SonoScene {
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(39, 1, 0.1, 80);
  private renderer: THREE.WebGLRenderer;
  private root = new THREE.Group();
  private room = new THREE.Group();
  private bedFurniture: THREE.Group | null = null;
  private ambient = new THREE.Group();
  private head = new THREE.Group();
  private leftWing = new THREE.Group();
  private rightWing = new THREE.Group();
  private leftEye!: THREE.Mesh;
  private rightEye!: THREE.Mesh;
  private lowerBeak!: THREE.Mesh;
  private outfitGroup = new THREE.Group();
  private headOutfitGroup = new THREE.Group();
  private particles = new THREE.Group();
  private effects = new THREE.Group();
  private sleepStars = new THREE.Group();
  private dirt = new THREE.Group();
  private dirtTexture = makeDirtTexture();
  private cleanliness = 100;
  private washProgress = 0;
  private washEnabled = false;
  private scrubPoint: { x: number; y: number } | null = null;
  private scrubDistance = 0;
  private scrubCompleted = false;
  private bedPhase = 0;
  private bedFrom = 0;
  private bedTarget = 0;
  private bedMotionStart = 0;
  private bedMotionDuration = 1200;
  private autoWakeAt: number | null = null;
  private autoWakeAnimating = false;
  private bedSleepClipStarted = false;
  private bedOccupied = false;
  private empty = false;
  private rigBeak: THREE.Object3D | null = null;
  private rigHead: THREE.Object3D | null = null;
  private spongeCursor = document.createElement("button");
  private washInput: "pointer" | "touch" | null = null;
  private washPointerId: number | null = null;
  private touchId: number | null = null;
  private animation = "idle";
  private animationItem?: string;
  private animationStarted = 0;
  private animationDuration = 0;
  private sleeping = false;
  private disposed = false;
  private resizeObserver: ResizeObserver;
  private roomName: PetRoom | null = null;
  private outfitName: PetOutfit | null = null;
  private raycaster = new THREE.Raycaster();
  private pointer = new THREE.Vector2();
  private pointerX = 0;
  private pointerY = 0;
  private targetYaw = 0;
  private dragStart: { x: number; y: number; yaw: number } | null = null;
  private dragged = false;
  private hotspots: THREE.Object3D[] = [];
  private night = false;
  private reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)")
    .matches;
  private sun: THREE.DirectionalLight;
  private backdrop: HTMLElement;
  private mixer: THREE.AnimationMixer | null = null;
  private rigActions = new Map<string, THREE.AnimationAction>();
  private currentRigAction: THREE.AnimationAction | null = null;
  private modelLoaded = false;
  private lastTickTime = 0;
  readonly ready: Promise<boolean>;

  constructor(
    private container: HTMLElement,
    private onInteraction: (interaction: SceneInteraction) => void,
    private onWashComplete?: () => void,
    private onWashProgress?: (progress: number) => void,
    private onAutoWakeComplete?: () => void,
  ) {
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: "high-performance",
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.backdrop = document.createElement("div");
    this.backdrop.className = "scene-backdrop";
    this.container.append(this.backdrop, this.renderer.domElement);
    this.spongeCursor.className = "sponge-cursor";
    this.spongeCursor.type = "button";
    this.spongeCursor.setAttribute(
      "aria-label",
      "Drag sponge over Sono to wash",
    );
    this.spongeCursor.textContent = "🧽";
    this.spongeCursor.hidden = true;
    this.container.append(this.spongeCursor);
    this.spongeCursor.addEventListener("pointerdown", this.spongePointerDown);
    this.spongeCursor.addEventListener("touchstart", this.spongeTouchStart, {
      passive: false,
    });
    window.addEventListener("pointermove", this.spongePointerMove);
    window.addEventListener("pointerup", this.spongePointerUp);
    window.addEventListener("pointercancel", this.spongePointerUp);
    window.addEventListener("touchmove", this.spongeTouchMove, {
      passive: false,
    });
    window.addEventListener("touchend", this.spongeTouchEnd);
    window.addEventListener("touchcancel", this.spongeTouchEnd);
    this.camera.position.set(0, 1.9, 8.6);
    this.camera.lookAt(0, 1.1, 0);
    this.scene.add(new THREE.HemisphereLight(0xffffff, 0xb5a3cf, 2.2));
    this.sun = new THREE.DirectionalLight(0xffffff, 2.9);
    this.sun.position.set(-3, 7, 5);
    this.scene.add(this.sun);
    const fill = new THREE.PointLight(0xbab5ff, 35, 12);
    fill.position.set(3, 3, 4);
    this.scene.add(fill);
    this.buildBird();
    this.scene.add(this.root);
    this.scene.add(this.room);
    this.scene.add(this.ambient);
    this.setRoom("living");
    this.ready = this.loadRig();
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(container);
    this.resize();
    this.renderer.domElement.style.touchAction = "none";
    this.renderer.domElement.addEventListener("pointerdown", this.pointerDown);
    this.renderer.domElement.addEventListener("pointermove", this.pointerMove);
    this.renderer.domElement.addEventListener("pointerup", this.pointerUp);
    this.renderer.domElement.addEventListener(
      "pointercancel",
      this.pointerCancel,
    );
    this.renderer.setAnimationLoop((time) => this.tick(time));
    document.addEventListener("visibilitychange", this.visibility);
  }

  private visibility = () => {
    if (document.hidden) this.renderer.setAnimationLoop(null);
    else this.renderer.setAnimationLoop((time) => this.tick(time));
  };
  private resize() {
    const width = Math.max(1, this.container.clientWidth),
      height = Math.max(1, this.container.clientHeight);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height, false);
  }
  private async loadRig(): Promise<boolean> {
    try {
      const asset = await new GLTFLoader().loadAsync("/assets/sono-rig.glb");
      if (this.disposed) return false;
      const persistent = new Set<THREE.Object3D>([
        this.outfitGroup,
        this.particles,
        this.effects,
        this.sleepStars,
        this.dirt,
      ]);
      for (const child of [...this.root.children]) {
        if (persistent.has(child)) continue;
        this.disposeGroup(child);
        this.root.remove(child);
      }
      this.root.add(asset.scene);
      const head = asset.scene.getObjectByName("Head");
      this.rigHead = head ?? null;
      this.rigBeak = asset.scene.getObjectByName("UpperBeak") ?? null;
      head?.add(this.headOutfitGroup);
      this.mixer = new THREE.AnimationMixer(asset.scene);
      for (const clip of asset.animations)
        this.rigActions.set(clip.name, this.mixer.clipAction(clip));
      this.modelLoaded = true;
      this.container.dataset.rig = "glb";
      const outfit = this.outfitName ?? "none";
      this.outfitName = null;
      this.setOutfit(outfit);
      this.playRig(this.sleeping ? "sleepIdle" : "idle");
      return true;
    } catch (error) {
      this.container.dataset.rig = "procedural";
      console.warn("Sono rig unavailable; using procedural fallback", error);
      return false;
    }
  }
  private playRig(kind: string, duration?: number) {
    const next = this.rigActions.get(kind);
    if (!next || next === this.currentRigAction) return;
    this.currentRigAction?.fadeOut(0.18);
    next.reset();
    next.enabled = true;
    next.setEffectiveWeight(1);
    const looping = kind === "idle" || kind === "sleepIdle";
    next.setLoop(
      looping ? THREE.LoopRepeat : THREE.LoopOnce,
      looping ? Infinity : 1,
    );
    next.clampWhenFinished = !looping;
    if (!looping && duration)
      next.setEffectiveTimeScale(next.getClip().duration / (duration / 1000));
    else next.setEffectiveTimeScale(1);
    next.fadeIn(0.18).play();
    this.currentRigAction = next;
  }
  private pointerDown = (event: PointerEvent) => {
    this.dragStart = {
      x: event.clientX,
      y: event.clientY,
      yaw: this.targetYaw,
    };
    this.dragged = false;
    try {
      this.renderer.domElement.setPointerCapture(event.pointerId);
    } catch {
      /* a cancelled pointer can no longer be captured */
    }
  };
  private pointerMove = (event: PointerEvent) => {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.pointerX = THREE.MathUtils.clamp(
      ((event.clientX - rect.left) / rect.width) * 2 - 1,
      -1,
      1,
    );
    this.pointerY = THREE.MathUtils.clamp(
      ((event.clientY - rect.top) / rect.height) * 2 - 1,
      -1,
      1,
    );
    if (!this.reducedMotion)
      this.backdrop.style.transform = `translate3d(${-this.pointerX * 6}px, ${-this.pointerY * 4}px, 0)`;
    if (this.dragStart) {
      const dx = event.clientX - this.dragStart.x;
      const dy = event.clientY - this.dragStart.y;
      if (Math.hypot(dx, dy) > 12) this.dragged = true;
      if (this.dragged)
        this.targetYaw = THREE.MathUtils.clamp(
          this.dragStart.yaw + dx * 0.006,
          -0.65,
          0.65,
        );
    }
  };
  private pointerUp = (event: PointerEvent) => {
    if (this.dragStart && !this.dragged) this.pick(event);
    this.dragStart = null;
    if (this.renderer.domElement.hasPointerCapture(event.pointerId))
      this.renderer.domElement.releasePointerCapture(event.pointerId);
  };
  private pointerCancel = () => {
    this.dragStart = null;
    this.dragged = false;
  };
  private pick(event: PointerEvent) {
    if (this.empty) return;
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.pointer.set(
      ((event.clientX - rect.left) / rect.width) * 2 - 1,
      -((event.clientY - rect.top) / rect.height) * 2 + 1,
    );
    this.raycaster.setFromCamera(this.pointer, this.camera);
    const hits = this.raycaster.intersectObjects(
      [this.root, ...this.hotspots],
      true,
    );
    for (const hit of hits) {
      let object: THREE.Object3D | null = hit.object;
      while (object && object !== this.scene) {
        const hotspot = object.userData.hotspot as SceneInteraction | undefined;
        if (hotspot) {
          if (hotspot === "window") this.toggleWindow();
          this.onInteraction(hotspot);
          return;
        }
        if (object === this.root) {
          this.onInteraction("character");
          return;
        }
        object = object.parent;
      }
    }
  }
  private markHotspot(object: THREE.Object3D, kind: SceneInteraction) {
    object.userData.hotspot = kind;
    object.userData.baseY = object.position.y;
    this.hotspots.push(object);
  }
  private toggleWindow() {
    this.night = !this.night;
    this.backdrop.classList.toggle("night", this.night);
    this.sun.intensity = this.night ? 1.4 : 2.9;
  }
  private buildBird() {
    const shadow = new THREE.Mesh(
      new THREE.CircleGeometry(0.8, 32),
      new THREE.MeshBasicMaterial({
        color: 0x3b305c,
        transparent: true,
        opacity: 0.18,
        depthWrite: false,
      }),
    );
    shadow.rotation.x = -Math.PI / 2;
    shadow.scale.y = 0.48;
    shadow.position.set(0, -0.39, 0.15);
    this.scene.add(shadow);
    sphere(this.root, purple, [0, 1.1, 0], [0.66, 0.92, 0.57], 32);
    this.head.position.y = 2.13;
    sphere(this.head, purple, [0, 0, 0], [0.81, 0.76, 0.7], 36);
    for (const sign of [-1, 1]) {
      const eyeX = sign * 0.29;
      const eye = sphere(
        this.head,
        white,
        [eyeX, 0.12, 0.58],
        [0.23, 0.27, 0.105],
      );
      sphere(this.head, iris, [eyeX - 0.02, 0.07, 0.68], [0.13, 0.17, 0.047]);
      sphere(
        this.head,
        black,
        [eyeX - 0.02, 0.06, 0.725],
        [0.086, 0.12, 0.027],
      );
      sphere(
        this.head,
        white,
        [eyeX - 0.06, 0.13, 0.75],
        [0.035, 0.047, 0.015],
        16,
      );
      const brow = sphere(
        this.head,
        purpleDark,
        [eyeX, 0.46, 0.52],
        [0.25, 0.036, 0.05],
      );
      brow.rotation.z = sign * -0.16;
      if (sign === -1) this.leftEye = eye;
      else this.rightEye = eye;
    }
    this.head.add(curvedBeak());
    this.lowerBeak = sphere(
      this.head,
      orangeDark,
      [0, -0.49, 0.78],
      [0.17, 0.065, 0.22],
      20,
    );
    const tuft = sphere(
      this.head,
      purple,
      [-0.11, 0.74, -0.03],
      [0.17, 0.34, 0.18],
    );
    tuft.rotation.z = -0.45;
    const tuft2 = sphere(
      this.head,
      purpleLight,
      [0.1, 0.68, -0.06],
      [0.13, 0.28, 0.14],
    );
    tuft2.rotation.z = 0.75;
    this.root.add(this.head);
    for (const sign of [-1, 1]) {
      const wing = new THREE.Group();
      wing.position.set(sign * 0.57, 1.43, -0.01);
      const feather = sphere(
        wing,
        purple,
        [sign * 0.14, -0.25, 0.04],
        [0.22, 0.59, 0.32],
      );
      feather.rotation.z = sign * 0.27;
      sphere(wing, purpleLight, [sign * 0.25, -0.58, 0.05], [0.15, 0.24, 0.23]);
      this.root.add(wing);
      if (sign === -1) this.leftWing = wing;
      else this.rightWing = wing;
      sphere(this.root, orange, [sign * 0.24, 0.16, 0.02], [0.09, 0.43, 0.09]);
      sphere(this.root, orange, [sign * 0.24, -0.27, 0.25], [0.18, 0.1, 0.31]);
      for (let toe = -1; toe <= 1; toe++)
        sphere(
          this.root,
          orange,
          [sign * 0.24 + toe * 0.12, -0.31, 0.48],
          [0.085, 0.08, 0.17],
          16,
        );
    }
    for (let i = -1; i <= 1; i++) {
      const tail = sphere(
        this.root,
        green,
        [i * 0.38, 0.66, -0.53],
        [0.17, 0.48, 0.15],
      );
      tail.rotation.z = -i * 0.62;
      tail.rotation.x = -0.5;
    }
    this.root.add(this.outfitGroup);
    this.root.add(this.particles);
    this.root.add(this.effects);
    for (let i = 0; i < 3; i++) {
      const star = sphere(
        this.sleepStars,
        new THREE.MeshBasicMaterial({ color: 0xffd970 }),
        [-0.52 + i * 0.45, 3.0 + (i % 2) * 0.18, 0.2],
        [0.045, 0.045, 0.045],
        12,
      );
      star.userData.baseY = star.position.y;
    }
    this.root.add(this.sleepStars);
    const smudges: Array<[number, number, number, number]> = [
      [-0.35, 1.25, 0.74, 0.18],
      [0.29, 1.48, 0.74, 0.14],
      [-0.17, 0.79, 0.72, 0.12],
      [0.41, 0.92, 0.64, 0.15],
      [-0.44, 1.53, 0.65, 0.11],
      [0.42, 1.18, 0.67, 0.12],
      [0.04, 1.84, 0.6, 0.1],
      [-0.33, 1.65, 0.67, 0.1],
    ];
    smudges.forEach(([x, y, z, radius], index) => {
      const patch = new THREE.Mesh(
        new THREE.PlaneGeometry(radius * 3.2, radius * 2.4),
        new THREE.MeshBasicMaterial({
          map: this.dirtTexture,
          color: index % 3 === 0 ? 0xd6bd9f : 0xf1dbc1,
          transparent: true,
          opacity: 0.6,
          depthWrite: false,
          side: THREE.DoubleSide,
        }),
      );
      patch.position.set(x, y, z);
      patch.rotation.z = index * 0.7;
      this.dirt.add(patch);
    });
    this.root.add(this.dirt);
    this.updateDirt();
  }

  private project(point: THREE.Vector3) {
    this.root.updateWorldMatrix(true, true);
    const rect = this.renderer.domElement.getBoundingClientRect();
    const projected = point.project(this.camera);
    return {
      x: rect.left + ((projected.x + 1) / 2) * rect.width,
      y: rect.top + ((1 - projected.y) / 2) * rect.height,
    };
  }
  getMouthPoint() {
    const point = this.rigBeak
      ? this.rigBeak.localToWorld(new THREE.Vector3(0, -0.35, 0.92))
      : this.root.localToWorld(new THREE.Vector3(0, 1.82, 0.91));
    return this.project(point);
  }
  private moveSponge(x: number, y: number) {
    const rect = this.container.getBoundingClientRect();
    this.spongeCursor.style.left = `${x - rect.left}px`;
    this.spongeCursor.style.top = `${y - rect.top}px`;
  }
  private startWash(x: number, y: number, input: "pointer" | "touch") {
    if (!this.washEnabled || this.scrubCompleted || this.washInput)
      return false;
    this.washInput = input;
    this.scrubPoint = { x, y };
    this.spongeCursor.classList.add("dragging");
    this.moveSponge(x, y);
    return true;
  }
  private continueWash(x: number, y: number) {
    if (!this.scrubPoint || !this.washEnabled) return;
    const dx = x - this.scrubPoint.x;
    const dy = y - this.scrubPoint.y;
    if (this.insideBird(x, y)) {
      this.scrubDistance += Math.min(35, Math.hypot(dx, dy));
      this.setWashProgress(Math.min(1, this.scrubDistance / 320));
      this.onWashProgress?.(this.washProgress);
      if (this.washProgress >= 1 && !this.scrubCompleted) {
        this.scrubCompleted = true;
        this.onWashComplete?.();
        return;
      }
    }
    this.scrubPoint = { x, y };
    this.moveSponge(x, y);
  }
  private finishWash() {
    this.washInput = null;
    this.washPointerId = null;
    this.touchId = null;
    this.scrubPoint = null;
    this.spongeCursor.classList.remove("dragging");
    this.spongeCursor.style.removeProperty("left");
    this.spongeCursor.style.removeProperty("top");
  }
  private spongePointerDown = (event: PointerEvent) => {
    if (event.pointerType === "touch") return;
    if (!this.startWash(event.clientX, event.clientY, "pointer")) return;
    event.preventDefault();
    this.washPointerId = event.pointerId;
    try {
      this.spongeCursor.setPointerCapture(event.pointerId);
    } catch {
      /* synthetic pointer tests do not have a native capture target */
    }
  };
  private spongePointerMove = (event: PointerEvent) => {
    if (this.washInput === "pointer" && event.pointerId === this.washPointerId)
      this.continueWash(event.clientX, event.clientY);
  };
  private spongePointerUp = (event: PointerEvent) => {
    if (this.washInput === "pointer" && event.pointerId === this.washPointerId)
      this.finishWash();
  };
  private spongeTouchStart = (event: TouchEvent) => {
    const touch = event.changedTouches[0];
    if (!touch || !this.startWash(touch.clientX, touch.clientY, "touch"))
      return;
    this.touchId = touch.identifier;
    event.preventDefault();
  };
  private spongeTouchMove = (event: TouchEvent) => {
    if (this.washInput !== "touch") return;
    const touch = Array.from(event.touches).find(
      (point) => point.identifier === this.touchId,
    );
    if (!touch) return;
    event.preventDefault();
    this.continueWash(touch.clientX, touch.clientY);
  };
  private spongeTouchEnd = (event: TouchEvent) => {
    if (
      this.washInput === "touch" &&
      Array.from(event.changedTouches).some(
        (point) => point.identifier === this.touchId,
      )
    )
      this.finishWash();
  };
  private insideBird(x: number, y: number) {
    const top = this.project(
      this.root.localToWorld(new THREE.Vector3(0, 2.7, 0)),
    );
    const bottom = this.project(
      this.root.localToWorld(new THREE.Vector3(0, 0.35, 0)),
    );
    const centerX = (top.x + bottom.x) / 2;
    return (
      Math.abs(x - centerX) < Math.max(65, this.container.clientWidth * 0.19) &&
      y > top.y - 25 &&
      y < bottom.y + 25
    );
  }
  setCleanliness(value: number) {
    this.cleanliness = THREE.MathUtils.clamp(value, 0, 100);
    this.updateDirt();
  }
  setWashMode(enabled: boolean) {
    this.washEnabled = enabled;
    this.spongeCursor.hidden = !enabled;
    if (!enabled && this.washInput) this.finishWash();
  }
  setWashProgress(progress: number) {
    this.washProgress = THREE.MathUtils.clamp(progress, 0, 1);
    this.updateDirt();
  }
  resetWashProgress() {
    this.finishWash();
    this.scrubDistance = 0;
    this.scrubCompleted = false;
    this.setWashProgress(0);
  }
  private updateDirt() {
    const dirtiness = (100 - this.cleanliness) * (1 - this.washProgress);
    this.dirt.children.forEach((patch, index) => {
      const threshold = (index + 0.25) * 10;
      patch.visible = dirtiness > threshold;
      const material = (patch as THREE.Mesh)
        .material as THREE.MeshBasicMaterial;
      material.opacity = Math.min(
        0.68,
        Math.max(0, (dirtiness - threshold) / 28),
      );
    });
  }

  setRoom(room: PetRoom) {
    if (this.roomName === room) return;
    this.resetWashProgress();
    if (room !== "bedroom") {
      this.bedPhase = 0;
      this.bedTarget = 0;
      this.bedMotionStart = 0;
    } else if (this.bedOccupied) {
      this.bedPhase = 1;
      this.bedTarget = 1;
      this.bedMotionStart = 0;
    }
    this.roomName = room;
    this.disposeGroup(this.room);
    this.disposeGroup(this.ambient);
    this.room.clear();
    this.bedFurniture = null;
    this.ambient.clear();
    this.hotspots = [];
    this.night = false;
    this.sun.intensity = room === "bedroom" ? 1.9 : 2.9;
    this.backdrop.style.backgroundImage = `url(/assets/rooms/${room === "living" ? "playroom" : room === "bedroom" ? "bedroom-nobed" : room}.jpg)`;
    this.backdrop.classList.remove("night");
    this.scene.background = null;

    const windowTarget = new THREE.Mesh(
      new THREE.PlaneGeometry(1.2, 1.45),
      new THREE.MeshBasicMaterial({
        transparent: true,
        opacity: 0,
        depthWrite: false,
      }),
    );
    windowTarget.position.set(-1.7, 2.28, -0.4);
    this.room.add(windowTarget);
    this.markHotspot(windowTarget, "window");

    // The illustrated room supplies depth and furniture. Only foreground
    // objects that react to touch are real geometry, so the WebView stays light.
    if (room === "living") {
      const ball = sphere(
        this.room,
        new THREE.MeshStandardMaterial({
          color: 0xffcd53,
          roughness: 0.36,
          metalness: 0.05,
        }),
        [-1.18, -0.22, 0.45],
        [0.31, 0.31, 0.31],
      );
      this.markHotspot(ball, "play");
      sphere(this.room, white, [-1.18, -0.22, 0.75], [0.07, 0.07, 0.015], 12);
    } else if (room === "kitchen") {
      const snack = sphere(
        this.room,
        new THREE.MeshStandardMaterial({ color: 0xf45b53, roughness: 0.42 }),
        [-1.18, 0.13, 0.4],
        [0.23, 0.22, 0.23],
      );
      this.markHotspot(snack, "feed");
      const leaf = sphere(
        this.room,
        green,
        [-1.13, 0.37, 0.4],
        [0.11, 0.045, 0.06],
        12,
      );
      leaf.rotation.z = -0.3;
    } else if (room === "bedroom") {
      const bed = new THREE.Group();
      bed.visible = true;
      this.bedFurniture = bed;
      this.room.add(bed);
      box(bed, 0x8c60be, [1.12, -0.2, -0.42], [1.78, 0.4, 2.96]);
      box(bed, 0xeacdf7, [1.12, 0.06, -0.42], [1.62, 0.22, 2.8]);
      box(bed, 0xfff7e9, [1.12, 0.2, -1.48], [1.25, 0.16, 0.52]);
      box(bed, 0xa9e0db, [1.12, 0.18, 0.5], [1.55, 0.1, 1.02]);
      box(bed, 0x956dc2, [1.12, 0.34, -1.98], [1.8, 0.78, 0.18]);
      const bedTarget = new THREE.Mesh(
        new THREE.PlaneGeometry(1.35, 1.2),
        new THREE.MeshBasicMaterial({
          transparent: true,
          opacity: 0,
          depthWrite: false,
        }),
      );
      bedTarget.position.set(1.55, 0.55, 0.05);
      this.room.add(bedTarget);
      this.markHotspot(bedTarget, "sleep");
    } else {
      const tubTarget = new THREE.Mesh(
        new THREE.PlaneGeometry(1.35, 1.45),
        new THREE.MeshBasicMaterial({
          transparent: true,
          opacity: 0,
          depthWrite: false,
        }),
      );
      tubTarget.position.set(1.55, 0.68, 0.05);
      this.room.add(tubTarget);
      this.markHotspot(tubTarget, "wash");
    }

    const ambientColor = {
      living: 0xffe772,
      kitchen: 0xffe29a,
      bedroom: 0xffd66e,
      bathroom: 0xc7f6ff,
    }[room];
    const ambientMaterial = new THREE.MeshBasicMaterial({
      color: ambientColor,
      transparent: true,
      opacity: room === "bathroom" ? 0.48 : 0.67,
      depthWrite: false,
    });
    const ambientGeometry = new THREE.SphereGeometry(1, 8, 8);
    for (let i = 0; i < 14; i++) {
      const dot = new THREE.Mesh(ambientGeometry, ambientMaterial);
      const x = -2.1 + ((i * 17) % 43) / 10;
      const y = 0.18 + ((i * 11) % 34) / 10;
      dot.position.set(x, y, -0.8);
      dot.scale.setScalar(
        room === "bathroom" ? 0.055 + (i % 3) * 0.025 : 0.025 + (i % 4) * 0.012,
      );
      dot.userData.baseX = x;
      dot.userData.baseY = y;
      dot.userData.phase = i * 1.31;
      dot.userData.baseScale = dot.scale.x;
      this.ambient.add(dot);
    }
  }
  setEmpty(value: boolean) {
    this.empty = value;
    this.container.dataset.empty = String(value);
    this.root.visible = !value;
    this.room.visible = !value;
    this.ambient.visible = !value;
    this.particles.visible = !value;
    this.effects.visible = !value;
    if (value) this.spongeCursor.hidden = true;
  }
  setOutfit(outfit: PetOutfit) {
    if (this.outfitName === outfit) return;
    this.outfitName = outfit;
    this.disposeGroup(this.outfitGroup);
    this.outfitGroup.clear();
    this.disposeGroup(this.headOutfitGroup);
    this.headOutfitGroup.clear();
    if (outfit === "scarf") {
      const torus = new THREE.Mesh(
        new THREE.TorusGeometry(0.46, 0.12, 10, 32),
        new THREE.MeshStandardMaterial({ color: 0xf488a1 }),
      );
      torus.rotation.x = Math.PI / 2;
      torus.position.set(0, 1.58, 0);
      this.outfitGroup.add(torus);
      box(
        this.outfitGroup,
        0xf488a1,
        [0.38, 1.26, 0.52],
        [0.17, 0.45, 0.08],
        -0.15,
      );
    } else if (outfit === "hoodie") {
      sphere(
        this.outfitGroup,
        new THREE.MeshStandardMaterial({ color: 0x54bdb3 }),
        [0, 0.96, 0.03],
        [0.69, 0.64, 0.62],
        28,
      );
      box(this.outfitGroup, 0xf8f3ff, [-0.15, 1.21, 0.63], [0.027, 0.32, 0.02]);
      box(this.outfitGroup, 0xf8f3ff, [0.15, 1.21, 0.63], [0.027, 0.32, 0.02]);
    } else if (outfit === "sunglasses") {
      const target = this.modelLoaded ? this.headOutfitGroup : this.outfitGroup;
      const y = this.modelLoaded ? -2.13 : 0;
      const lens = new THREE.MeshPhysicalMaterial({
        color: 0x161725,
        roughness: 0.2,
        metalness: 0.15,
        transparent: true,
        opacity: 0.96,
      });
      for (const x of [-0.29, 0.29]) {
        sphere(target, lens, [x, 2.24 + y, 0.75], [0.24, 0.17, 0.065]);
        sphere(
          target,
          white,
          [x - 0.08, 2.3 + y, 0.815],
          [0.06, 0.016, 0.006],
          12,
        );
      }
      box(target, 0x252538, [0, 2.3 + y, 0.77], [0.18, 0.06, 0.09]);
      box(target, 0x252538, [-0.62, 2.32 + y, 0.58], [0.27, 0.05, 0.07]);
      box(target, 0x252538, [0.62, 2.32 + y, 0.58], [0.27, 0.05, 0.07]);
    }
  }
  setSleeping(value: boolean) {
    const changed = this.sleeping !== value;
    this.sleeping = value;
    if (changed && value) this.bedOccupied = true;
    if (
      changed &&
      value &&
      this.roomName === "bedroom" &&
      this.bedTarget === 0
    ) {
      this.bedPhase = 1;
      this.bedTarget = 1;
      this.bedMotionStart = 0;
      this.playRig("sleepIdle");
    } else if (
      changed &&
      !value &&
      this.bedOccupied &&
      this.autoWakeAt === null
    ) {
      this.wakeFromBed();
    } else if (
      changed &&
      !value &&
      this.bedTarget === 0 &&
      this.bedMotionStart === 0 &&
      this.animation === "idle"
    ) {
      this.playRig("idle");
    }
  }
  beginBedtime(duration = 3500, autoWake = false) {
    if (this.roomName !== "bedroom") return;
    this.bedOccupied = true;
    this.bedFrom = this.bedPhase;
    this.bedTarget = 1;
    this.bedMotionStart = performance.now();
    this.bedMotionDuration = this.reducedMotion ? 450 : 1300;
    this.bedSleepClipStarted = false;
    this.autoWakeAt = autoWake
      ? this.bedMotionStart + Math.max(2200, duration - 900)
      : null;
    this.playRig("walk", 650);
  }
  wakeFromBed(automatic = false) {
    this.bedOccupied = false;
    if (this.roomName !== "bedroom") {
      this.bedPhase = 0;
      this.bedTarget = 0;
      this.bedMotionStart = 0;
      this.autoWakeAt = null;
      if (automatic) this.onAutoWakeComplete?.();
      return;
    }
    this.bedFrom = this.bedPhase;
    this.bedTarget = 0;
    this.bedMotionStart = performance.now();
    this.bedMotionDuration = this.reducedMotion ? 450 : 1150;
    this.autoWakeAt = null;
    this.autoWakeAnimating = automatic;
    this.playRig("wake", this.bedMotionDuration);
  }
  private disposeGroup(group: THREE.Object3D) {
    const shared = new Set<THREE.Material>([
      purple,
      purpleLight,
      purpleDark,
      orange,
      orangeDark,
      green,
      white,
      iris,
      black,
    ]);
    group.traverse((object) => {
      if (object instanceof THREE.Mesh) {
        object.geometry.dispose();
        const materials = Array.isArray(object.material)
          ? object.material
          : [object.material];
        for (const material of materials)
          if (!shared.has(material)) material.dispose();
      }
    });
  }
  play(kind: string, duration = 2100, item?: string) {
    this.animation = kind;
    this.animationItem = item;
    this.animationStarted = performance.now();
    this.animationDuration = duration;
    this.playRig(kind === "refuse" ? "idle" : kind, duration);
    this.disposeGroup(this.particles);
    this.particles.clear();
    this.particles.position.set(0, 0, 0);
    this.particles.scale.setScalar(1);
    this.disposeGroup(this.effects);
    this.effects.clear();
    if (kind === "feed") {
      if (item === "toast") {
        box(this.particles, 0xe9ac67, [0, 0, 0], [0.3, 0.27, 0.08]);
        box(this.particles, 0xffe0a7, [0, 0, 0.05], [0.23, 0.2, 0.015]);
      } else if (item === "berries") {
        for (let i = 0; i < 4; i++)
          sphere(
            this.particles,
            new THREE.MeshStandardMaterial({ color: 0x6565cb }),
            [(i % 2) * 0.14 - 0.07, Math.floor(i / 2) * 0.13 - 0.05, 0],
            [0.09, 0.09, 0.09],
            12,
          );
      } else {
        sphere(
          this.particles,
          new THREE.MeshStandardMaterial({ color: 0xe9595d }),
          [0, 0, 0],
          [0.18, 0.18, 0.18],
        );
        sphere(
          this.particles,
          green,
          [0.03, 0.18, 0],
          [0.07, 0.035, 0.035],
          12,
        );
      }
    } else if (kind === "play") {
      if (item === "bubbles") {
        const bubble = new THREE.MeshPhysicalMaterial({
          color: 0xa4e9ee,
          transparent: true,
          opacity: 0.65,
          roughness: 0.08,
        });
        for (let i = 0; i < 5; i++) {
          const b = sphere(
            this.particles,
            bubble,
            [(i - 2) * 0.13, (i % 3) * 0.12, 0],
            [0.09 + (i % 2) * 0.035, 0.09 + (i % 2) * 0.035, 0.09],
            12,
          );
          b.userData.baseY = b.position.y;
        }
      } else if (item === "blocks") {
        for (let i = 0; i < 3; i++) {
          const block = box(
            this.particles,
            [0xf3b364, 0x8ddcc7, 0xaf91e8][i],
            [(i - 1) * 0.18, (i % 2) * 0.16, 0],
            [0.18, 0.18, 0.18],
          );
          block.userData.role = "block";
        }
      } else {
        sphere(
          this.particles,
          new THREE.MeshStandardMaterial({ color: 0xf0779d }),
          [0, 0, 0],
          [0.24, 0.24, 0.24],
        );
      }
    } else if (kind === "wash") {
      const bubble = new THREE.MeshPhysicalMaterial({
        color: 0xc5f7ff,
        transparent: true,
        opacity: 0.62,
        roughness: 0.1,
      });
      for (let i = 0; i < 11; i++) {
        const b = sphere(
          this.particles,
          bubble,
          [Math.sin(i * 2.1) * 0.78, 0.3 + (i % 5) * 0.45, 0.65],
          [0.08 + (i % 3) * 0.025, 0.08 + (i % 3) * 0.025, 0.08],
          14,
        );
        b.userData.baseY = b.position.y;
      }
    } else if (kind === "pet") {
      const heart = new THREE.MeshStandardMaterial({
        color: 0xf38ab4,
        roughness: 0.45,
      });
      for (let i = 0; i < 5; i++) {
        const sparkle = sphere(
          this.particles,
          heart,
          [-0.55 + i * 0.28, 2.6 + (i % 2) * 0.18, 0.8],
          [0.085, 0.085, 0.055],
          12,
        );
        sparkle.userData.baseY = sparkle.position.y;
      }
    }
    if (["play", "feed", "wash", "equip", "wake"].includes(kind)) {
      const colors =
        kind === "wash"
          ? [0xcafaff, 0xffffff, 0x8cebe7]
          : [0xffdf6b, 0xff89bf, 0x91edc5, 0xbba0ff];
      const count = this.reducedMotion ? 4 : 12;
      for (let i = 0; i < count; i++) {
        const sparkle = sphere(
          this.effects,
          new THREE.MeshBasicMaterial({
            color: colors[i % colors.length],
            transparent: true,
            opacity: kind === "wash" ? 0.58 : 0.88,
            depthWrite: false,
          }),
          [0, 1.4, 0.9],
          [0.035 + (i % 3) * 0.012, 0.035 + (i % 3) * 0.012, 0.035],
          8,
        );
        sparkle.userData.role = "sparkle";
        sparkle.userData.angle = (i / count) * Math.PI * 2;
        sparkle.userData.radius = 0.38 + (i % 3) * 0.2;
      }
    }
  }
  private tick(time: number) {
    if (this.disposed || document.hidden) return;
    const delta = this.lastTickTime
      ? Math.min(0.05, (time - this.lastTickTime) / 1000)
      : 0;
    this.lastTickTime = time;
    this.mixer?.update(delta);
    if (this.autoWakeAt !== null && time >= this.autoWakeAt)
      this.wakeFromBed(true);
    if (this.bedMotionStart > 0) {
      const progress = Math.min(
        1,
        (time - this.bedMotionStart) / this.bedMotionDuration,
      );
      const eased = progress * progress * (3 - 2 * progress);
      this.bedPhase = THREE.MathUtils.lerp(this.bedFrom, this.bedTarget, eased);
      if (
        this.bedTarget === 1 &&
        !this.bedSleepClipStarted &&
        this.bedPhase > 0.45
      ) {
        this.bedSleepClipStarted = true;
        this.playRig("sleep", 900);
      }
      if (progress >= 1) {
        this.bedMotionStart = 0;
        this.playRig(this.bedTarget === 1 ? "sleepIdle" : "idle");
        if (this.bedTarget === 0 && this.autoWakeAnimating) {
          this.autoWakeAnimating = false;
          this.onAutoWakeComplete?.();
        }
      }
    }
    const t = time * 0.001;
    const elapsed = time - this.animationStarted;
    if (this.animation !== "idle" && elapsed > this.animationDuration) {
      this.animation = "idle";
      this.playRig(this.sleeping ? "sleepIdle" : "idle");
      this.disposeGroup(this.particles);
      this.particles.clear();
      this.particles.position.set(0, 0, 0);
      this.disposeGroup(this.effects);
      this.effects.clear();
    }
    const p = Math.min(
      1,
      Math.max(0, elapsed / Math.max(1, this.animationDuration)),
    );
    const active = this.animation !== "idle";
    const wave = Math.sin(p * Math.PI * 4) * Math.sin(p * Math.PI);
    const motion = this.reducedMotion ? 0.25 : 1;
    this.root.position.x = 0;
    this.root.position.z = 0;
    this.root.rotation.x = 0;
    this.root.position.y =
      this.sleeping && this.bedPhase === 0
        ? -0.18 + Math.sin(t * 1.8) * 0.015 * motion
        : Math.sin(t * 2.2) * 0.035 * motion;
    this.root.rotation.z = 0;
    this.root.scale.set(1, 1, 1);
    this.root.rotation.y += (this.targetYaw - this.root.rotation.y) * 0.12;
    this.head.rotation.z = Math.sin(t * 1.4) * 0.025 * motion;
    this.head.rotation.y +=
      (this.pointerX * 0.16 - this.head.rotation.y) * 0.08;
    this.head.rotation.x +=
      (-this.pointerY * 0.07 - this.head.rotation.x) * 0.08;
    this.leftWing.rotation.z = -0.05;
    this.rightWing.rotation.z = 0.05;
    this.lowerBeak.position.y = -0.49;
    const bed = this.bedPhase;
    this.container.dataset.bedPhase = bed.toFixed(2);
    if (this.bedFurniture) this.bedFurniture.visible = true;
    this.camera.position.set(
      THREE.MathUtils.lerp(this.pointerX * 0.18, 1.12, bed),
      THREE.MathUtils.lerp(1.9 - this.pointerY * 0.08, 9.4, bed),
      THREE.MathUtils.lerp(8.6, 1.0, bed),
    );
    this.camera.lookAt(
      THREE.MathUtils.lerp(0, 1.12, bed),
      THREE.MathUtils.lerp(1.1, 0.3, bed),
      THREE.MathUtils.lerp(0, -1.0, bed),
    );
    if (active && this.animation === "play") {
      this.root.position.y +=
        Math.abs(Math.sin(p * Math.PI * 5)) *
        (this.modelLoaded ? 0.08 : 0.3) *
        motion;
      this.root.scale.y = 1 + Math.sin(p * Math.PI * 5) * 0.055 * motion;
      this.leftWing.rotation.z = -0.7 + wave * 0.4;
      this.rightWing.rotation.z = 0.7 - wave * 0.4;
    } else if (active && this.animation === "feed") {
      this.head.rotation.x = Math.sin(p * Math.PI * 7) * 0.18;
      this.lowerBeak.position.y -= Math.abs(Math.sin(p * Math.PI * 9)) * 0.095;
      this.leftWing.rotation.z = -0.28;
    } else if (active && this.animation === "wash") {
      this.root.rotation.z = wave * 0.085;
      this.head.rotation.z += Math.sin(p * Math.PI * 6) * 0.05;
      this.leftWing.rotation.z = -0.45 + Math.sin(p * Math.PI * 10) * 0.23;
      this.rightWing.rotation.z = 0.45 - Math.sin(p * Math.PI * 10) * 0.23;
      this.root.scale.x = 1 + Math.sin(p * Math.PI * 8) * 0.025;
    } else if (active && this.animation === "sleep") {
      this.head.rotation.z -= Math.sin(p * Math.PI * 0.5) * 0.13;
      this.root.position.y -= Math.sin(p * Math.PI * 0.5) * 0.08;
      this.leftWing.rotation.z = -0.18;
      this.rightWing.rotation.z = 0.18;
    } else if (active && this.animation === "wake") {
      this.root.position.y += Math.sin(p * Math.PI) * 0.22 * motion;
      this.leftWing.rotation.z = -0.2 - Math.sin(p * Math.PI) * 0.55;
      this.rightWing.rotation.z = 0.2 + Math.sin(p * Math.PI) * 0.55;
    } else if (active && this.animation === "equip") {
      this.root.rotation.y += Math.sin(p * Math.PI * 2) * 0.25 * motion;
    } else if (active && this.animation === "wave") {
      this.rightWing.rotation.z = 0.95 + Math.sin(p * Math.PI * 6) * 0.25;
    } else if (active && this.animation === "pet") {
      this.head.rotation.z += Math.sin(p * Math.PI * 3) * 0.15 * motion;
      this.leftWing.rotation.z = -0.35;
      this.rightWing.rotation.z = 0.35;
    } else if (active && this.animation === "refuse") {
      this.root.rotation.y += Math.sin(p * Math.PI * 8) * 0.08 * motion;
      this.head.rotation.y += Math.sin(p * Math.PI * 8) * 0.42 * motion;
      if (this.rigHead)
        this.rigHead.rotation.y += Math.sin(p * Math.PI * 8) * 0.42 * motion;
    }
    if (bed > 0) {
      const lie = THREE.MathUtils.smoothstep(bed, 0.3, 1);
      this.root.position.x = 1.12 * bed;
      this.root.position.y = THREE.MathUtils.lerp(
        this.root.position.y,
        0.52,
        lie,
      );
      this.root.position.z = -0.35 * bed;
      this.root.rotation.x = (-Math.PI / 2) * lie;
      this.root.rotation.y *= 1 - bed;
      this.root.scale.setScalar(1 - 0.42 * lie);
    }
    if (this.animation === "feed") {
      this.particles.position.set(0.9 * (1 - p), 0.5 + 1.15 * p, 0.95);
      this.particles.scale.setScalar(
        p > 0.72 ? Math.max(0.01, 1 - (p - 0.72) * 3.5) : 1,
      );
    } else if (this.animation === "play") {
      this.particles.position.set(
        0.78 - 1.56 * p,
        0.35 + Math.abs(Math.sin(p * Math.PI * 4)) * 0.45,
        0.8,
      );
      if (this.animationItem === "blocks")
        this.particles.children.forEach(
          (block, i) =>
            (block.rotation.z = Math.sin(p * Math.PI * 4 + i) * 0.7),
        );
      if (this.animationItem === "bubbles")
        this.particles.children.forEach(
          (bubble, i) =>
            (bubble.position.y = bubble.userData.baseY + p * (0.35 + i * 0.07)),
        );
    } else if (this.animation === "wash") {
      for (const b of this.particles.children)
        b.position.y =
          b.userData.baseY + p * 0.6 + Math.sin(t * 5 + b.id) * 0.035;
    } else if (this.animation === "pet") {
      for (const [i, sparkle] of this.particles.children.entries()) {
        sparkle.position.y = sparkle.userData.baseY + p * 0.48;
        sparkle.position.x += Math.sin(t * 2 + i) * 0.0008;
      }
      this.particles.scale.setScalar(Math.max(0.01, 1 - p * p));
    }
    for (const effect of this.effects.children) {
      if (effect.userData.role === "sparkle") {
        const angle = effect.userData.angle as number;
        const radius =
          (effect.userData.radius as number) *
          Math.sin(Math.min(1, p * 1.25) * Math.PI * 0.72);
        effect.position.set(
          Math.cos(angle) * radius,
          1.45 + Math.sin(angle) * radius + p * 0.35,
          0.92,
        );
        const material = (effect as THREE.Mesh).material;
        if (material instanceof THREE.MeshBasicMaterial)
          material.opacity = Math.max(0, 0.9 - p * 0.75);
      }
    }
    for (const dot of this.ambient.children) {
      const phase = dot.userData.phase as number;
      dot.position.x =
        dot.userData.baseX + Math.sin(t * 0.75 + phase) * 0.09 * motion;
      dot.position.y =
        this.roomName === "bathroom"
          ? -0.25 +
            ((dot.userData.baseY + t * (0.12 + (phase % 3) * 0.025)) % 4.1)
          : dot.userData.baseY + Math.sin(t * 0.92 + phase) * 0.14 * motion;
      dot.scale.setScalar(
        dot.userData.baseScale *
          (1 + Math.sin(t * 1.8 + phase) * 0.22 * motion),
      );
    }
    for (const hotspot of this.hotspots) {
      if (hotspot.userData.hotspot === "play")
        hotspot.position.y =
          hotspot.userData.baseY + Math.abs(Math.sin(t * 1.8)) * 0.06 * motion;
      else if (hotspot.userData.hotspot === "feed")
        hotspot.rotation.z = Math.sin(t * 1.5) * 0.07 * motion;
    }
    this.sleepStars.visible =
      this.sleeping || (this.bedTarget === 1 && bed > 0.7);
    this.sleepStars.children.forEach(
      (star, i) =>
        (star.position.y = star.userData.baseY + Math.sin(t * 1.8 + i) * 0.07),
    );
    const blink =
      this.sleeping || (this.bedTarget === 1 && bed > 0.7)
        ? 0.12
        : Math.sin(t * 0.7) > 0.997
          ? 0.12
          : 1;
    this.leftEye.scale.y = 0.27 * blink;
    this.rightEye.scale.y = 0.27 * blink;
    this.renderer.render(this.scene, this.camera);
  }
  dispose() {
    this.disposed = true;
    this.mixer?.stopAllAction();
    this.resizeObserver.disconnect();
    document.removeEventListener("visibilitychange", this.visibility);
    this.renderer.domElement.removeEventListener(
      "pointerdown",
      this.pointerDown,
    );
    this.renderer.domElement.removeEventListener(
      "pointermove",
      this.pointerMove,
    );
    this.renderer.domElement.removeEventListener("pointerup", this.pointerUp);
    this.renderer.domElement.removeEventListener(
      "pointercancel",
      this.pointerCancel,
    );
    this.spongeCursor.removeEventListener(
      "pointerdown",
      this.spongePointerDown,
    );
    this.spongeCursor.removeEventListener("touchstart", this.spongeTouchStart);
    window.removeEventListener("pointermove", this.spongePointerMove);
    window.removeEventListener("pointerup", this.spongePointerUp);
    window.removeEventListener("pointercancel", this.spongePointerUp);
    window.removeEventListener("touchmove", this.spongeTouchMove);
    window.removeEventListener("touchend", this.spongeTouchEnd);
    window.removeEventListener("touchcancel", this.spongeTouchEnd);
    this.renderer.setAnimationLoop(null);
    this.disposeGroup(this.room);
    this.disposeGroup(this.ambient);
    this.disposeGroup(this.root);
    this.renderer.dispose();
    this.dirtTexture.dispose();
    this.renderer.domElement.remove();
    this.backdrop.remove();
    this.spongeCursor.remove();
  }
}
